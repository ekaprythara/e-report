<?php $__env->startSection('body'); ?>
<div class="h1 fw-bold">Laporan Kartu Stok</div>
<div class="container rounded p-3 bg-white mb-3">
    <div class="d-flex justify-content-start align items center mb-2">
        <span class="container input-group">
            <input type="text" class="form-control" placeholder="Input group example" aria-label="Input group example"
                aria-describedby="btnGroupAddon">
            <div class="input-group-text" id="btnGroupAddon"><i class="bi bi-calendar"></i></div>
        </span>
        <span class="container input-group">
            <input type="text" class="form-control" placeholder="Input group example" aria-label="Input group example"
                aria-describedby="btnGroupAddon">
            <div class="input-group-text" id="btnGroupAddon"><i class="bi bi-calendar"></i></div>
        </span>
    </div>
    <table id="tb-lpKartuStok" class="table table-bordered table-striped" style="width:100%">
        <thead>
            <tr>
                <th>No.</th>
                <th>Logistik</th>
                <th>Masuk</th>
                <th>Keluar</th>
                <th>Stok</th>
                <th>Satuan</th>
                <th>Distribusi</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th>1</th>
                <th>Mie Instan</th>
                <th>400</th>
                <th>0</th>
                <th>400</th>
                <th>Pcs</th>
                <th></th>
            </tr>
            <tr>
                <th>2</th>
                <th>Pakaian Pria</th>
                <th>200</th>
                <th>50</th>
                <th>150</th>
                <th>Paket</th>
                <th></th>
            </tr>
            <tr>
                <th>3</th>
                <th>Pakaian Wanita</th>
                <th>200</th>
                <th>0</th>
                <th>200</th>
                <th>Paket</th>
                <th></th>
            </tr>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pyzakke/public_html/test/resources/views/lp-kartu-stok.blade.php ENDPATH**/ ?>