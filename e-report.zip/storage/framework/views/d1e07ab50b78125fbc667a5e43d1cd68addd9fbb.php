<!DOCTYPE html>
<html>

<head>
    <style>
        #title {
            text-align: center;
            line-height: 2px;
            padding: 5px 5px 5px;
        }

        #head {
            width: 100%;
        }

        #head tr td {
            text-align: center;
            font-size: small;
        }

        #head tr td hr {
            width: 90%;
        }

        #head tr td p {
            line-height: 5px;
        }

        #head tr td h3 {
            line-height: 5px;
        }

        body {
            font-family: Arial, Helvetica, sans-serif;
        }

        #body {
            border-collapse: collapse;
            width: 100%;
            font-size: small;
        }

        #body td,
        #body th {
            padding: 5px;
            border: 1px solid #313335;
        }

        #body tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #body th {
            padding-top: 10px;
            padding-bottom: 10px;
            text-align: left;
            background-color: #313335;
            color: white;
        }

        #foot {
            margin-top: 20px;
            font-size: small;
            text-align: left;
            float: right;
            line-height: 5px;
        }
    </style>
</head>

<body>
    <table id="head">
        <tr>
            <td>
                <img src="<?php echo e(public_path('/img/logo-pemprov.png')); ?>" alt="" width="120" height="120">
            </td>
            <td>
                <h3>Badan Penanggulangan Bencana Daerah Provinsi Bali</h3>
                <hr>
                <p>Jalan D.I. Panjaitan No. 6 Renon - Denpasar 80235</p>
                <p>Telp. 0361-245397, Fax. 0361-245395</p>
            </td>
            <td>
                <img src="<?php echo e(public_path('/img/logo-bpbd-provinsi-bali.png')); ?>" alt="" width="120"
                    height="120">
            </td>
        </tr>
    </table>

    <hr>

    <div id="title">
        <h3>LAPORAN STOK LOGISTIK</h3>
    </div>

    <table id="body">
        <thead>
            <tr>
                <th>No.</th>
                <th>Logistik</th>
                <th>Jenis Logistik</th>
                <th>Stok</th>
                <th>Satuan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $logistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($logistic->name); ?></td>
                    <td><?php echo e($logistic->logisticType->name); ?></td>
                    <td><?php echo e($logistic->stock); ?></td>
                    <td><?php echo e($logistic->standardUnit->name); ?></td>
                </tr>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <table id="foot">
        <tr>
            <td>
                <p>Denpasar,
                    <?php
                        $date = Carbon\Carbon::now()->locale('id');
                        $date->settings(['formatFunction' => 'translatedFormat']);
                        echo $date->format('d F Y');
                    ?>
                </p>
                <p>Kepala Sub Bidang Logistik dan Peralatan</p>
                <p></p>
                <p></p>
                <p></p>
                <p></p>
                <p></p>
                <strong><u><?php echo e(Auth::user()->name); ?></u></strong>
            </td>
        </tr>
    </table>
    </div>
</body>

</html>
<?php /**PATH /home/ekaprynthara/public_html/test/resources/views//ekspor/stok-logistik.blade.php ENDPATH**/ ?>