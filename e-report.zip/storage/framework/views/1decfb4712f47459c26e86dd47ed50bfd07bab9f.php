<!DOCTYPE html>
<html>

<head>
</head>

<body>
    <table>
        <tr>
            <td colspan="5" style="text-align: center;">
                <b>PEMERINTAH PROVINSI BALI</b>
            </td>
        </tr>
        <tr>
            <td colspan="5" style="text-align: center;">
                <b>Badan Penanggulangan Bencana Daerah</b>
            </td>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr>
            <td colspan="5" style="text-align: center;">
                <b>LAPORAN STOK LOGISTIK</b>
            </td>
        </tr>
    </table>

    <table>
        <thead>
            <tr>
                <th><b>No.</b></th>
                <th><b>Logistik</b></th>
                <th><b>Jenis Logistik</b></th>
                <th><b>Stok</b></th>
                <th><b>Satuan</b></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $logistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($logistic->name); ?></td>
                    <td><?php echo e($logistic->logisticType->name); ?></td>
                    <td>
                        <?php if($logistic->stock == 0): ?>
                            0
                        <?php else: ?>
                            <?php echo e($logistic->stock); ?>

                        <?php endif; ?>
                    </td>
                    <td><?php echo e($logistic->standardUnit->name); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr></tr>
            <tr></tr>
            <tr>
                <td colspan="5" style="text-align: right;">
                    <b>
                        Denpasar,
                        <?php
                            $date = Carbon\Carbon::now()->locale('id');
                            $date->settings(['formatFunction' => 'translatedFormat']);
                            echo $date->format('d F Y');
                        ?>
                    </b>
                </td>
            </tr>
            <tr>
                <td colspan="5" style="text-align: right;">
                    <b>
                        <?php echo e(Auth::user()->level->name); ?>

                        <?php if(Auth::user()->level_id == '1'): ?>
                            Kedaruratan dan Logistik
                        <?php else: ?>
                            Logistik dan Peralatan
                        <?php endif; ?>
                    </b>
                </td>
            </tr>
            <tr>
                <td colspan="5" rowspan="4">
                </td>
            </tr>
            <tr></tr>
            <tr></tr>
            <tr></tr>
            <tr>
                <td colspan="5" style="text-align: right; vertical-align:top; text-decoration:underline;">
                    <b>
                        <?php echo e(Auth::user()->name); ?>

                    </b>
                </td>
            </tr>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH /home/ekaprynthara/public_html/test/resources/views//ekspor/stok-logistik/excel.blade.php ENDPATH**/ ?>