<?php $__env->startSection('body'); ?>
    <div class="h1 fw-bold">Laporan Logistik Masuk</div>
    <div class="container-fluid rounded p-3 bg-white mb-3">
        <form action="/laporan/logistik-masuk/sort">
            <div class="d-flex justify-content-between align-items-start mb-2">
                <div class="d-flex align-items-start d-inline me-auto col-5">
                    <div class="input-group me-2">
                        <span class="input-group-text" id="mulai">Mulai</span>
                        <input type="text" class="form-control date-picker <?php $__errorArgs = ['from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="from" value="<?php echo e(request('from') ?? now()->toDateString()); ?>" aria-describedby="mulai">
                        <?php $__errorArgs = ['from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="input-group me-2">
                        <span class="input-group-text" id="sampai">Sampai</span>
                        <input type="text" class="form-control date-picker <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="to" value="<?php echo e(request('to') ?? now()->toDateString()); ?>" aria-describedby="sampai">
                        <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button type="submit" class="btn btn-primary me-2">
                        Cari
                    </button>
        </form>
        <form action="/laporan/logistik-masuk/reset" method="post">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary bi bi-arrow-clockwise"></button>
        </form>
    </div>

    <div class="d-flex d-inline justify-content-end p-0 mb-2">
        <button type="button" class="btn btn-success me-2" data-bs-toggle="modal" data-bs-target="#export">
            Ekspor
        </button>
        <div class="modal fade" id="export" tabindex="-1" aria-labelledby="exportLabel" aria-hidden="true">
            <div class="modal-dialog modal-md">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title fw-bold" id="exportLabel">Ekspor Laporan</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="/laporan/logistik-masuk/ekspor">
                            <div class="row mb-3">
                                <div class="col">
                                    <label for="exportFrom" class="form-label">Mulai</label>
                                    <input type="text"
                                        class="form-control date-picker <?php $__errorArgs = ['from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exportFrom"
                                        name="from" value="<?php echo e(now()->toDateString()); ?>">
                                    <?php $__errorArgs = ['from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col">
                                    <label for="exportTo" class="form-label">Sampai</label>
                                    <input type="text" class="form-control date-picker" id="exportTo" name="to"
                                        value="<?php echo e(now()->toDateString()); ?>">
                                </div>
                            </div>
                            <label for="format" class="form-label">Format</label>
                            <select class="form-select" id="format" name="format">
                                <option value="ods">ODS</option>
                                <option value="pdf">PDF</option>
                                <option value="xls">XLS</option>
                                <option value="xlsx">XLSX</option>
                            </select>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Ekspor</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#exampleModal">
            Cetak
        </button>
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-md">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title fw-bold" id="exampleModalLabel">Cetak Laporan</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="/laporan/logistik-masuk/print">
                            <div class="row">
                                <div class="col">
                                    <label for="printFrom" class="form-label">Mulai</label>
                                    <input type="text" class="form-control date-picker" id="printFrom" name="from"
                                        value="<?php echo e(now()->toDateString()); ?>">
                                </div>
                                <div class="col">
                                    <label for="printTo" class="form-label">Sampai</label>
                                    <input type="text" class="form-control date-picker" id="printTo" name="to"
                                        value="<?php echo e(now()->toDateString()); ?>">
                                </div>
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Cetak</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>
    
    <div class="table-responsive p-0 pt-3 pb-3">
        <table id="tb-logMasuk" class="table table-bordered table-striped" style="width:100%">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Tanggal Masuk</th>
                    <th>Logistik</th>
                    <th>Penyuplai</th>
                    <th>Jumlah</th>
                    <th>Satuan</th>
                    <th>Kedaluwarsa</th>
                    <th>Jenis Pengadaan</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $inboundLogistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inboundLogistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($inboundLogistic->inboundDate); ?></td>
                        <td><?php echo e($inboundLogistic->logistic->name); ?></td>
                        <td>
                            <?php echo e($inboundLogistic->supplier->name ?? $inboundLogistic->supplier); ?>

                        </td>
                        <td class="text-right"><?php echo e($inboundLogistic->amount); ?></td>
                        <td><?php echo e($inboundLogistic->logistic->standardUnit->name); ?></td>
                        <td><?php echo e($inboundLogistic->expiredDate); ?></td>
                        <td>
                            <?php echo e($inboundLogistic->logisticProcurement->name ?? $inboundLogistic->logisticProcurement); ?>

                        </td>
                        <td><?php echo e($inboundLogistic->description); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ekaprynthara/public_html/test/resources/views//laporan/logistik-masuk.blade.php ENDPATH**/ ?>