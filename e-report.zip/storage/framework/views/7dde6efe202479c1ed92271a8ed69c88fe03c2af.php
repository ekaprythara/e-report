<?php $__env->startSection('body'); ?>
    <div class="d-flex justify-content-center align-content-center">
        <div class="p-3 rounded bg-light">
            <h1 class="h3 mb-3 fw-normal">Registrasi</h1>
            <hr>
            <?php if(session()->has('create')): ?>
                <div class="alert alert-success" id="success-alert" role="alert">
                    <?php echo e(session('create')); ?>

                </div>
            <?php endif; ?>
            <form action="/sign-up" method="post">
                <?php echo csrf_field(); ?>
                
                <div class="row mb-3">
                    <div class="col">
                        <label for="username" class="form-label">Nama Pengguna</label>
                        <input type="text" class="form-control" id="username" name="username">
                    </div>
                    <div class="col">
                        <label for="password" class="form-label">Kata Sandi</label>
                        <input type="password" class="form-control" id="password" name="password">
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col">
                        <label for="name" class="form-label">Nama Lengkap</label>
                        <input type="text" class="form-control" id="name" name="name">
                    </div>
                    <div class="col">
                        <label for="address" class="form-label">Alamat</label>
                        <input type="text" class="form-control" id="address" name="address">
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col">
                        <label for="email" class="form-label">Surel</label>
                        <input type="email" class="form-control" id="email" name="email">
                    </div>
                    <div class="col">
                        <label for="phone" class="form-label">Telepon</label>
                        <input type="tel" class="form-control" id="phone" name="phone">
                    </div>
                </div>
                <label for="level" class="form-label">Level</label>
                <select class="form-select" id="level" name="level_id" disabled>
                    <option selected>Admin</option>
                </select>
                <input type="hidden" name="level_id" value="1">
                <hr>
                <button class="w-100 btn btn-primary mb-3" type="submit">Masuk</button>
                <small class="text-center d-block">Sudah terdaftar? <a href="/sign-in">Masuk</a></small>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('/layouts/sign-in', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pyzakke/public_html/test/resources/views//sign-up/index.blade.php ENDPATH**/ ?>