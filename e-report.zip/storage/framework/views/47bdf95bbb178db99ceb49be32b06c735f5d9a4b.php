<?php $__env->startSection('body'); ?>
    <div class="h1 fw-bold">Laporan Logistik Masuk</div>
    <div class="container rounded p-3 bg-white mb-3">
        <table id="tb-lpLogMasuk" class="table table-bordered table-striped" style="width:100%">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Tanggal Masuk</th>
                    <th>Logistik</th>
                    <th>Penyuplai</th>
                    <th>Jumlah</th>
                    <th>Tanggal Kadaluarsa</th>
                    <th>Jenis Pengadaan</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th>1</th>
                    <th>12-04-2022</th>
                    <th>Mie Instan</th>
                    <th>PT. Indofood</th>
                    <th>400</th>
                    <th>01-04-2023</th>
                    <th>Bantuan</th>
                    <th></th>
                </tr>
                <tr>
                    <th>2</th>
                    <th>12-04-2022</th>
                    <th>Pakaian Pria</th>
                    <th>PT. Bintang Sejahtera</th>
                    <th>200</th>
                    <th></th>
                    <th>Bantuan</th>
                    <th></th>
                </tr>
                <tr>
                    <th>3</th>
                    <th>12-04-2022</th>
                    <th>Pakaian Wanita</th>
                    <th>PT. Sudi Makmur</th>
                    <th>200</th>
                    <th></th>
                    <th>Bantuan</th>
                    <th></th>
                </tr>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pyzakke/public_html/test/resources/views/lp-logistik-masuk.blade.php ENDPATH**/ ?>