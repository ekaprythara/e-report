<?php $__env->startSection('body'); ?>
    <div class="h1 fw-bold">Logistik</div>
    <div class="container rounded p-3 bg-white mb-3">
        <div class="d-flex justify-content-end align items center mb-2">
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                Tambah
            </button>
        </div>
        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title fw-bold" id="exampleModalLabel">Tambah Logistik</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="logistik" method="post">
                            <?php echo csrf_field(); ?>
                            <label for="addName" class="form-label">Logistik</label>
                            <input type="text" class="form-control mb-3" id="addName" name="name">
                            <div class="row mb-3">
                                <div class="col">
                                    <label for="addLogisticType" class="form-label">Jenis Logistik</label>
                                    <select class="form-select" id="addLogisticType" name="logisticType_id">
                                        <option selected>Pilih...</option>
                                        <?php $__currentLoopData = $logisticTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logisticType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($logisticType->id); ?>"><?php echo e($logisticType->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col">
                                    <label for="addStandardUnit" class="form-label">Satuan</label>
                                    <select class="form-select" id="addStandardUnit" name="standardUnit_id">
                                        <option selected>Pilih...</option>
                                        <?php $__currentLoopData = $standardUnits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $standardUnit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($standardUnit->id); ?>"><?php echo e($standardUnit->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <label for="addDescription" class="form-label">Keterangan</label>
                            <textarea class="form-control" id="addDescription" name="description"></textarea>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- CRUD Alert -->
        <?php if(session()->has('create')): ?>
            <div class="alert alert-success" id="success-alert" role="alert">
                <?php echo e(session('create')); ?>

            </div>
        <?php elseif(session()->has('update')): ?>
            <div class="alert alert-warning" id="warning-alert" role="alert">
                <?php echo e(session('update')); ?>

            </div>
        <?php elseif(session()->has('delete')): ?>
            <div class="alert alert-danger" id="danger-alert" role="alert">
                <?php echo e(session('delete')); ?>

            </div>
        <?php endif; ?>

        <!-- Table -->
        <table id="tb-logistik" class="table table-bordered table-striped" style="width:100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Logistik</th>
                    <th>Jenis Logistik</th>
                    <th>Satuan</th>
                    <th>Keterangan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $logistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($logistic->name); ?></td>
                        <td><?php echo e($logistic->logisticType->name); ?></td>
                        <td><?php echo e($logistic->standardUnit->name); ?></td>
                        <td><?php echo e($logistic->description); ?></td>
                        <td class="mb-1">
                            <!-- Modal Info -->
                            <a class="btn btn-sm btn-success text-light me-1" data-bs-toggle="modal"
                                data-bs-target="#modalInfo<?php echo e($logistic->id); ?>">Info</a>
                            <div class="modal fade" id="modalInfo<?php echo e($logistic->id); ?>" tabindex="-1"
                                aria-labelledby="detailLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title fw-bold" id="detailLabel">Info</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form>
                                                <label for="infoName<?php echo e($logistic->id); ?>"
                                                    class="form-label">Logistik</label>
                                                <input type="text" class="form-control mb-3"
                                                    id="infoName<?php echo e($logistic->id); ?>" value="<?php echo e($logistic->name); ?>"
                                                    disabled>
                                                <div class="row mb-3">
                                                    <div class="col">
                                                        <label for="infoLogisticType<?php echo e($logistic->id); ?>"
                                                            class="form-label">Jenis
                                                            Logistik</label>
                                                        <select class="form-select"
                                                            id="infoLogisticType<?php echo e($logistic->id); ?>" disabled>
                                                            <option selected><?php echo e($logistic->logisticType->name); ?>

                                                            </option>
                                                        </select>
                                                    </div>
                                                    <div class="col">
                                                        <label for="infoStandardUnit<?php echo e($logistic->id); ?>"
                                                            class="form-label">Satuan</label>
                                                        <select class="form-select"
                                                            id="infoStandardUnit<?php echo e($logistic->id); ?>" disabled>
                                                            <option selected><?php echo e($logistic->standardUnit->name); ?>

                                                            </option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <label for="infoDescription<?php echo e($logistic->id); ?>"
                                                    class="form-label">Keterangan</label>
                                                <textarea class="form-control" id="infoDescription<?php echo e($logistic->id); ?>"
                                                    disabled><?php echo e($logistic->description); ?></textarea>
                                            </form>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Tutup</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Edit -->
                            <a class="btn btn-sm btn-warning text-light me-1" data-bs-toggle="modal"
                                data-bs-target="#modalEdit<?php echo e($logistic->id); ?>">Edit</a>
                            <div class="modal fade" id="modalEdit<?php echo e($logistic->id); ?>" tabindex="-1"
                                aria-labelledby="detailLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title fw-bold" id="detailLabel">Edit</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="logistik/<?php echo e($logistic->id); ?>" method="post">
                                                <?php echo method_field('put'); ?>
                                                <?php echo csrf_field(); ?>
                                                <label for="editName<?php echo e($logistic->id); ?>"
                                                    class="form-label">Logistik</label>
                                                <input type="text" class="form-control mb-3"
                                                    id="editName<?php echo e($logistic->id); ?>" value="<?php echo e($logistic->name); ?>"
                                                    name="name">
                                                <div class="row mb-3">
                                                    <div class="col">
                                                        <label for="editLogisticType<?php echo e($logistic->id); ?>"
                                                            class="form-label">Jenis
                                                            Logistik</label>
                                                        <select class="form-select"
                                                            id="editLogisticType<?php echo e($logistic->id); ?>"
                                                            name="logisticType_id">
                                                            <?php $__currentLoopData = $logisticTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logisticType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($logisticType->id == $logistic->logisticType->id): ?>
                                                                    <option value='<?php echo e($logisticType->id); ?>' selected>
                                                                        <?php echo e($logisticType->name); ?>

                                                                        *
                                                                    </option>
                                                                <?php else: ?>
                                                                    <option value='<?php echo e($logisticType->id); ?>'>
                                                                        <?php echo e($logisticType->name); ?>

                                                                    </option>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                    <div class="col">
                                                        <label for="editStandardUnit<?php echo e($logistic->id); ?>"
                                                            class="form-label">Satuan</label>
                                                        <select class="form-select"
                                                            id="editStandardUnit<?php echo e($logistic->id); ?>"
                                                            name="standardUnit_id">
                                                            <?php $__currentLoopData = $standardUnits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $standardUnit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($standardUnit->id == $logistic->standardUnit->id): ?>
                                                                    <option value='<?php echo e($standardUnit->id); ?>' selected>
                                                                        <?php echo e($standardUnit->name); ?>

                                                                        *
                                                                    </option>
                                                                <?php else: ?>
                                                                    <option value='<?php echo e($standardUnit->id); ?>'>
                                                                        <?php echo e($standardUnit->name); ?>

                                                                    </option>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <label for="editDescription<?php echo e($logistic->id); ?>"
                                                    class="form-label">Keterangan</label>
                                                <textarea class="form-control" id="editDescription<?php echo e($logistic->id); ?>"
                                                    name="description"><?php echo e($logistic->description); ?></textarea>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Tutup</button>
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- Hapus -->
                            <form action="logistik/<?php echo e($logistic->id); ?>" method="post" class="d-inline"
                                onsubmit="return confirm('Apakah Anda yakin untuk menghapus data <?php echo e($logistic->name); ?>?')">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger btn-sm" type="submit">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pyzakke/public_html/test/resources/views/logistik.blade.php ENDPATH**/ ?>