<!DOCTYPE html>
<html>

<head>
    <style>
        .page-break {
            page-break-before: auto;
        }

        body {
            font-family: Arial, Helvetica, sans-serif;
        }

        #head {
            width: 100%;
            line-height: 5px;
        }

        #head tr td {
            text-align: center;
            font-size: small;
        }

        #head tr td hr {
            width: 90%;
        }

        #title {
            text-align: center;
            line-height: 2px;
            padding: 5px 5px 5px;
        }

        #body {
            border-collapse: collapse;
            width: 100%;
            font-size: 10pt;
            color: black;
        }

        #body td,
        #body th {
            padding: 5px;
            border: 1px solid black;
        }

        #body tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #body th {
            padding-top: 10px;
            padding-bottom: 10px;
            text-align: left;
            background-color: #FEB139;
            color: black;
        }

        #foot {
            margin-top: 20px;
            font-size: small;
            text-align: left;
            float: right;
            line-height: 5px;
        }
    </style>
</head>

<body>
    <div class="page-break">
        <table id="head">
            <tr>
                <td>
                    <img src="<?php echo e(public_path('/img/logo-pemprov.png')); ?>" alt="" width="120" height="120">
                </td>
                <td>
                    <h2>PEMERINTAH PROVINSI BALI</h2>
                    <h2>Badan Penanggulangan Bencana Daerah</h2>
                    <p>Jalan D.I. Panjaitan No. 6 Denpasar - Bali 80235</p>
                    <p>Telp: 0361-245397, Fax: 0361-245395</p>
                    <p>Laman: <a href="http://www.bpbd.baliprov.go.id/">bpbd.baliprov.go.id</a>, Surel:
                        bpbd@baliprov.go.id
                    </p>
                </td>
                <td>
                    <img src="<?php echo e(public_path('/img/logo-bpbd-provinsi-bali.png')); ?>" alt="" width="120"
                        height="120">
                </td>
            </tr>
        </table>
        <hr>
        <div id="title">
            <h3>LAPORAN KADALUARSA</h3>
        </div>
    </div>

    <table id="body">
        <thead>
            <tr>
                <th>No</th>
                <th>Logistik</th>
                <th>Penyuplai</th>
                <th>Stok</th>
                <th>Satuan</th>
                <th>Kadaluarsa</th>
                <th>Jenis Pengadaan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $inboundLogistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inboundLogistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($inboundLogistic->logistic->name); ?></td>
                    <td>
                        <?php echo e($inboundLogistic->supplier->name ?? $inboundLogistic->supplier); ?>

                    </td>
                    <td><?php echo e($inboundLogistic->stock); ?></td>
                    <td><?php echo e($inboundLogistic->logistic->standardUnit->name); ?></td>
                    <td><?php echo e($inboundLogistic->expiredDate); ?></td>
                    <td>
                        <?php echo e($inboundLogistic->logisticProcurement->name ?? $inboundLogistic->logisticProcurement); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="page-break">
        <table id="foot">
            <tr>
                <td>
                    <p>Denpasar,
                        <?php
                            $date = Carbon\Carbon::now()->locale('id');
                            $date->settings(['formatFunction' => 'translatedFormat']);
                            echo $date->format('d F Y');
                        ?>
                    </p>
                    <p>
                        <?php echo e(Auth::user()->level->name); ?>

                        <?php if(Auth::user()->level_id == '1'): ?>
                            Kedaruratan dan Logistik
                        <?php else: ?>
                            Logistik dan Peralatan
                        <?php endif; ?>
                    </p>
                    <p></p>
                    <p></p>
                    <p></p>
                    <p></p>
                    <p></p>
                    <strong><u><?php echo e(Auth::user()->name); ?></u></strong>
                </td>
            </tr>
        </table>
    </div>
</body>

</html>
<?php /**PATH /home/ekaprynthara/public_html/test/resources/views//ekspor/kadaluarsa/pdf.blade.php ENDPATH**/ ?>