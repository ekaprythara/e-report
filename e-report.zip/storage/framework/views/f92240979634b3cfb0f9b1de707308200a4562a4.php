<?php $__env->startSection('body'); ?>
<div class="h1 fw-bold">Logistik Masuk</div>
<div class="container-fluid rounded p-3 bg-white mb-3">
    <div class="d-flex justify-content-end align-items-center mb-2">
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
            Tambah
        </button>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold" id="exampleModalLabel">Tambah Logistik Masuk</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="/logistik-masuk" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row mb-3">
                            <div class="col">
                                <label for="inboundDate" class="form-label">Tanggal Masuk</label>
                                <input type="date" class="form-control" id="inboundDate" name="inboundDate"
                                    placeholder="dd-mm-yyyy" value="<?php echo e(now()->toDateString()); ?>">
                            </div>
                            <div class="col">
                                <label for="logMasukPenyuplai" class="form-label">Penyuplai</label>
                                <select class="form-select" id="logMasukPenyuplai" name="supplier_id">
                                    <option selected>Pilih Penyuplai</option>
                                    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col">
                                <label for="logMasukJenisPengadaan" class="form-label">Jenis Pengadaan</label>
                                <select class="form-select" id="logMasukJenisPengadaan" name="logisticProcurement_id">
                                    <option selected>Pilih Jenis Pengadaan</option>
                                    <?php $__currentLoopData = $logisticProcurements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logisticProcurement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($logisticProcurement->id); ?>">
                                        <?php echo e($logisticProcurement->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <label for="tb_logistikMasukModal" class="form-label">Logistik</label>
                        <div class="container-fluid border p-3 mb-3">
                            <table id="tb-modLogMasuk" class="table table-bordered table-striped table-sm"
                                style="width:100%">
                                <thead>
                                    <tr>
                                        <th></th>
                                        <th>Logistik</th>
                                        <th>Jumlah</th>
                                        <th>Satuan</th>
                                        <th>Tanggal Kadaluarsa</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $logistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <input class="form-check-input" type="checkbox" id="flexCheckDefault"
                                                name="logistic_id" value="<?php echo e($logistic->id); ?>">
                                        </td>
                                        <td><?php echo e($logistic->name); ?></td>
                                        <td>
                                            <input type="text" class="form-control" name="amount" disabled>
                                        </td>
                                        <td><?php echo e($logistic->standardUnit->name); ?></td>
                                        <td>
                                            <?php if($logistic->logisticType->expiredDate == 1): ?>
                                            <input type="date" class="form-control" id="expiredDate"
                                                name="expiredDate" disabled>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                            <button type="submit" class="btn btn-primary">Tambah</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php if(session()->has('create')): ?>
    <div class="alert alert-success" id="success-alert" role="alert">
        <?php echo e(session('create')); ?>

    </div>
    <?php elseif(session()->has('update')): ?>
    <div class="alert alert-warning" id="warning-alert" role="alert">
        <?php echo e(session('update')); ?>

    </div>
    <?php elseif(session()->has('delete')): ?>
    <div class="alert alert-danger" id="danger-alert" role="alert">
        <?php echo e(session('delete')); ?>

    </div>
    <?php endif; ?>

    <!-- Table -->
    <table id="tb-logistikMasuk" class="table table-bordered table-striped" style="width:100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal Masuk</th>
                <th>Logistik</th>
                <th>Penyuplai</th>
                <th>Jumlah</th>
                <th>Satuan</th>
                <th>Tanggal Kadaluarsa</th>
                <th>Jenis Pengadaan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $inboundLogistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inboundLogistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($inboundLogistic->inboundDate); ?></td>
                <td><?php echo e($inboundLogistic->logistic->name); ?></td>
                <td><?php echo e($inboundLogistic->supplier->name); ?></td>
                <td><?php echo e($inboundLogistic->amount); ?></td>
                <td><?php echo e($inboundLogistic->logistic->standardUnit->name); ?></td>
                <td><?php echo e($inboundLogistic->expiredDate); ?></td>
                <td><?php echo e($inboundLogistic->logisticProcurement->name); ?></td>
                <td>
                    <form action="/logistik-masuk/<?php echo e($inboundLogistic->id); ?>" method="post" class="d-inline"
                        onsubmit="return confirm('Apakah Anda yakin untuk menghapus data ini?')">
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-danger btn-sm" type="submit">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ekaprynthara/public_html/test/resources/views//logistik-masuk.blade.php ENDPATH**/ ?>