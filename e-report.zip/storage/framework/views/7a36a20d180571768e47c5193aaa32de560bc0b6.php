<div>
    <div class="mt-3">
        <label for="receiverUnit" class="form-label">Unit Penerima</label>
        <select wire:model="receiverUnit" class="form-select" id="receiverUnit">
            <option selected>Pilih Unit Penerima</option>
            <?php $__currentLoopData = $receiverUnits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receiverUnit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($receiverUnit->id); ?>"><?php echo e($receiverUnit->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="mt-3">
        <label for="receiver" class="form-label">Penerima</label>
        <select wire:model="receiver" class="form-select <?php $__errorArgs = ['receiver_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="receiver"
            name="receiver_id">
            <?php $__currentLoopData = $receivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receiver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($receiver->id); ?>"><?php echo e($receiver->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['receiver_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<?php /**PATH /home/ekaprynthara/public_html/test/resources/views/livewire/dropdown.blade.php ENDPATH**/ ?>