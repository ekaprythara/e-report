<?php $__env->startSection('body'); ?>
    <div class="h1 fw-bold">Jenis Logistik</div>
    <div class="container rounded p-3 bg-white mb-3">
        <div class="d-flex justify-content-end align items center mb-2">
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                Tambah
            </button>
        </div>

        
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title fw-bold" id="exampleModalLabel">Tambah Jenis Logistik</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="/data-master/jenis-logistik" method="post">
                            <?php echo csrf_field(); ?>
                            <label for="addName" class="form-label">Jenis Logistik</label>
                            <input type="text" class="form-control" id="addName" name="name">
                            <div class="mt-3">
                                <input class="form-check-input" type="hidden" value="0" name="expiredDate">
                                <input class="form-check-input" type="checkbox" id="addExpiredDate" name="expiredDate"
                                    value="1" <?php echo e(old('expiredDate') == 1 ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="addExpiredDate">
                                    Tambah tanggal kadaluarsa
                                </label>
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>

        
        <?php if(session()->has('create')): ?>
            <div class="alert alert-success" id="success-alert" role="alert">
                <?php echo e(session('create')); ?>

            </div>
        <?php elseif(session()->has('update')): ?>
            <div class="alert alert-warning" id="warning-alert" role="alert">
                <?php echo e(session('update')); ?>

            </div>
        <?php elseif(session()->has('delete')): ?>
            <div class="alert alert-danger" id="danger-alert" role="alert">
                <?php echo e(session('delete')); ?>

            </div>
        <?php endif; ?>

        
        <table id="tb-jenisLogistik" class="table table-bordered table-striped" style="width:100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Jenis Logistik</th>
                    <th>Tanggal Kadaluarsa</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $logisticTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logisticType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($logisticType->name); ?></td>
                        <?php if($logisticType->expiredDate == '1'): ?>
                            <td><span class="badge bg-success">Yes</span></td>
                        <?php else: ?>
                            <td><span class="badge bg-danger">No</span></td>
                        <?php endif; ?>
                        <td class="mb-1">
                            
                            <a class="btn btn-sm btn-warning text-light me-1" data-bs-toggle="modal"
                                data-bs-target="#modalEdit<?php echo e($logisticType->id); ?>">Edit</a>
                            <div class="modal fade" id="modalEdit<?php echo e($logisticType->id); ?>" tabindex="-1"
                                aria-labelledby="detailLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title fw-bold" id="detailLabel">Edit</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="/data-master/jenis-logistik/<?php echo e($logisticType->id); ?>"
                                                method="post">
                                                <?php echo method_field('put'); ?>
                                                <?php echo csrf_field(); ?>
                                                <label for="addName<?php echo e($logisticType->id); ?>" class="form-label">Jenis
                                                    Logistik</label>
                                                <input type="text" class="form-control"
                                                    id="addName<?php echo e($logisticType->id); ?>" name="name"
                                                    value="<?php echo e($logisticType->name); ?>">
                                                <div class="mt-3">
                                                    <input class="form-check-input" type="hidden" value="0"
                                                        name="expiredDate">
                                                    <input class="form-check-input" type="checkbox"
                                                        id="editExpiredDate<?php echo e($logisticType->id); ?>" name="expiredDate"
                                                        value="1"
                                                        <?php if($logisticType->expiredDate == '1'): ?> checked
                                                        <?php else: ?> <?php endif; ?>>
                                                    <label class="form-check-label"
                                                        for="editExpiredDate<?php echo e($logisticType->id); ?>">
                                                        Tambah tanggal kadaluarsa
                                                    </label>
                                                </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Tutup</button>
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                            <form action="/data-master/jenis-logistik/<?php echo e($logisticType->id); ?>" method="post"
                                class="d-inline"
                                onsubmit="return confirm('Apakah Anda yakin untuk menghapus data <?php echo e($logisticType->name); ?>?')">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger btn-sm" type="submit">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pyzakke/public_html/test/resources/views//data-master/jenis-logistik.blade.php ENDPATH**/ ?>