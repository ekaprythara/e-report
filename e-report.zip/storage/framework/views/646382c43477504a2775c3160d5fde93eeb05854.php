<?php $__env->startSection('body'); ?>
    <div class="h1 fw-bold">Jenis Pengadaan</div>
    <div class="container rounded p-3 bg-white mb-3">
        <div class="d-flex justify-content-end align items center mb-2">
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                Tambah
            </button>
        </div>

        
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title fw-bold" id="exampleModalLabel">Tambah Jenis Pengadaan</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form method="post" action="/data-master/jenis-pengadaan">
                            <?php echo csrf_field(); ?>
                            <label for="addName" class="form-label">Jenis Pengadaan</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="addName"
                                name="name" value="<?php echo e(old('name')); ?>">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>

        <?php if(session()->has('create')): ?>
            <div class="alert alert-success" id="success-alert" role="alert">
                <?php echo e(session('create')); ?>

            </div>
        <?php elseif(session()->has('update')): ?>
            <div class="alert alert-warning" id="warning-alert" role="alert">
                <?php echo e(session('update')); ?>

            </div>
        <?php elseif(session()->has('delete')): ?>
            <div class="alert alert-danger" id="danger-alert" role="alert">
                <?php echo e(session('delete')); ?>

            </div>
        <?php endif; ?>

        
        <table id="tb-jenisPengadaan" class="table table-bordered table-striped" style="width:100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Jenis Pengadaan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $logisticProcurements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logisticProcurement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($logisticProcurement->name); ?></td>
                        <td class="mb-1">
                            
                            <a class="btn btn-sm btn-warning text-light me-1" data-bs-toggle="modal"
                                data-bs-target="#modalEdit<?php echo e($logisticProcurement->id); ?>">Edit</a>
                            <div class="modal fade" id="modalEdit<?php echo e($logisticProcurement->id); ?>" tabindex="-1"
                                aria-labelledby="detailLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title fw-bold" id="detailLabel">Edit</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="/data-master/jenis-pengadaan/<?php echo e($logisticProcurement->id); ?>"
                                                method="post">
                                                <?php echo method_field('put'); ?>
                                                <?php echo csrf_field(); ?>
                                                <label for="editName<?php echo e($logisticProcurement->id); ?>"
                                                    class="form-label">Jenis
                                                    Pengadaan</label>
                                                <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="editName<?php echo e($logisticProcurement->id); ?>"
                                                    value="<?php echo e($logisticProcurement->name); ?>" name="name">
                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback">
                                                        <?php echo e($message); ?>

                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Tutup</button>
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                            <form action="/data-master/jenis-pengadaan/<?php echo e($logisticProcurement->id); ?>" method="post"
                                class="d-inline"
                                onsubmit="return confirm('Apakah Anda ingin menghapus data <?php echo e($logisticProcurement->name); ?>?')">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger btn-sm" type="submit">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pyzakke/public_html/test/resources/views//data-master/jenis-pengadaan.blade.php ENDPATH**/ ?>