<?php $__env->startSection('body'); ?>
    <div class="h1 fw-bold">Pengguna</div>
    <div class="container-fluid rounded p-3 bg-white mb-3">
        <div class="d-flex justify-content-end align items center mb-2 px-3">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kasubid')): ?>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    Tambah
                </button>
            </div>

            
            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title fw-bold" id="exampleModalLabel">Tambah Pengguna</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="/data-master/pengguna" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row mb-3">
                                    <div class="col">
                                        <label for="addUsername" class="form-label">Nama Pengguna</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="addUsername" name="username">
                                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col">
                                        <label for="addName" class="form-label">Nama Lengkap</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="addName" name="name">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col">
                                        <label for="addAddress" class="form-label">Alamat</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="addAddress" name="address">
                                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col">
                                        <label for="addEmail" class="form-label">Surel</label>
                                        <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="addEmail" name="email">
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col">
                                        <label for="addPhone" class="form-label">Telepon</label>
                                        <input type="tel" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="addPhone" name="phone">
                                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col">
                                        <label for="addPassword" class="form-label">Kata Sandi</label>
                                        <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="addPassword" name="password">
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col">
                                        <label for="addPasswordConfirmation" class="form-label">Konfirmasi Kata
                                            Sandi</label>
                                        <input type="password"
                                            class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="addPasswordConfirmation" name="password_confirmation">
                                        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="mb-3">
                                        <label for="addImage" class="form-label">Unggah Foto Profil</label>
                                        <img class="img-preview-add mb-2 col-sm-3">
                                        <input class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file"
                                            id="addImage" name="image" onchange="previewImageAddUser()">
                                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <label for="addLevel" class="form-label">Level</label>
                                <select class="form-select" id="addLevel" name="level_id" disabled>
                                    <option selected>Pegawai</option>
                                </select>
                                <input type="hidden" name="level_id" value="3">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                            <button type="submit" class="btn btn-primary">Tambah</button>
                        </div>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        
        <?php if(session()->has('create')): ?>
            <div class="alert alert-success" id="success-alert" role="alert">
                <?php echo e(session('create')); ?>

            </div>
        <?php elseif(session()->has('update')): ?>
            <div class="alert alert-warning" id="warning-alert" role="alert">
                <?php echo e(session('update')); ?>

            </div>
        <?php elseif(session()->has('delete')): ?>
            <div class="alert alert-danger" id="danger-alert" role="alert">
                <?php echo e(session('delete')); ?>

            </div>
        <?php endif; ?>

        <div class="table-responsive p-0 pt-3 pb-3">
            <table id="tb-pengguna" class="table table-bordered table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Foto</th>
                        <th>Nama Pengguna</th>
                        <th>Nama Lengkap</th>
                        <th>Level</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <?php if($user->image == null): ?>
                                    <img src="<?php echo e(asset('/img/default.png')); ?>"
                                        style="height: 100px; width: 100px; border-radius: 5px;">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('storage/' . $user->image)); ?>"
                                        style="height: 100px; width: 100px; border-radius: 5px;">
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($user->username); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->level->name); ?></td>
                            <td>
                                <div class="d-flex justify-content-center">
                                    
                                    <a class="btn btn-sm btn-primary text-light me-1 mb-2" data-bs-toggle="modal"
                                        data-bs-target="#modalInfo<?php echo e($user->id); ?>">Info</a>
                                    <div class="modal fade" id="modalInfo<?php echo e($user->id); ?>" tabindex="-1"
                                        aria-labelledby="detailLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title fw-bold" id="exampleModalLabel">Info Pengguna
                                                    </h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div
                                                        class="col d-flex flex-column justify-content-center align-items-center">
                                                        <?php if($user->image == null): ?>
                                                            <img src="<?php echo e(asset('/img/default.png')); ?>" width="180"
                                                                height="180"
                                                                class="rounded-circle me-2 mb-3 profile-bg-light">
                                                        <?php else: ?>
                                                            <img src="<?php echo e(asset('storage/' . $user->image)); ?>"
                                                                width="180" height="180"
                                                                class="rounded-circle me-2 mb-3 profile-bg-light">
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="row mb-3">
                                                        <div class="col">
                                                            <label for="infoUsername" class="form-label">Nama
                                                                Pengguna</label>
                                                            <input type="text" class="form-control" id="infoUsername"
                                                                name="username" value="<?php echo e($user->username); ?>" disabled>
                                                        </div>
                                                    </div>
                                                    <div class="row mb-3">
                                                        <div class="col">
                                                            <label for="infoName" class="form-label">Nama
                                                                Lengkap</label>
                                                            <input type="text" class="form-control" id="infoName"
                                                                name="name" value="<?php echo e($user->name); ?>" disabled>
                                                        </div>
                                                        <div class="col">
                                                            <label for="infoAddress" class="form-label">Alamat</label>
                                                            <input type="text" class="form-control" id="infoAddress"
                                                                name="address" value="<?php echo e($user->address); ?>" disabled>
                                                        </div>
                                                    </div>
                                                    <div class="row mb-3">
                                                        <div class="col">
                                                            <label for="infoEmail" class="form-label">Surel</label>
                                                            <input type="email" class="form-control" id="infoEmail"
                                                                name="email" value="<?php echo e($user->email); ?>" disabled>
                                                        </div>
                                                        <div class="col">
                                                            <label for="infoPhone" class="form-label">Telepon</label>
                                                            <input type="tel" class="form-control" id="infoPhone"
                                                                name="phone" value="<?php echo e($user->phone); ?>" disabled>
                                                        </div>
                                                    </div>
                                                    <label for="infoLevel" class="form-label">Level</label>
                                                    <select class="form-select" id="infoLevel" name="level_id" disabled>
                                                        <option selected><?php echo e($user->level->name); ?></option>
                                                    </select>
                                                </div>
                                                <div class="modal-footer d-flex flex-row-reverse justify-content-between">
                                                    <div>
                                                        <button type="button" class="btn btn-secondary me-1"
                                                            data-bs-dismiss="modal">Tutup</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <?php if(Auth::user()->id == $user->id): ?>
                                        <a class="btn btn-sm btn-warning text-light me-1 mb-2" data-bs-toggle="modal"
                                            data-bs-target="#modalEdit<?php echo e($user->id); ?>">Edit</a>
                                        <div class="modal fade" id="modalEdit<?php echo e($user->id); ?>" tabindex="-1"
                                            aria-labelledby="detailLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title fw-bold" id="exampleModalLabel">Edit
                                                            Pengguna</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form action="/data-master/pengguna/<?php echo e($user->id); ?>"
                                                            method="post" enctype="multipart/form-data">
                                                            <?php echo method_field('put'); ?>
                                                            <?php echo csrf_field(); ?>
                                                            <div class="row mb-3">
                                                                <div class="col">
                                                                    <label for="editUsername" class="form-label">Nama
                                                                        Pengguna</label>
                                                                    <input type="text"
                                                                        class="form-control <?php $__errorArgs = ['username', "edit$user->id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                        id="editUsername" name="username"
                                                                        value="<?php echo e($user->username); ?>">
                                                                    <?php $__errorArgs = ['username', "edit$user->id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="invalid-feedback">
                                                                            <?php echo e($message); ?>

                                                                        </div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                            <div class="row mb-3">
                                                                <div class="col">
                                                                    <label for="editName"
                                                                        class="form-label <?php $__errorArgs = ['name', "edit$user->id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Nama
                                                                        Lengkap</label>
                                                                    <input type="text" class="form-control"
                                                                        id="editName" name="name"
                                                                        value="<?php echo e($user->name); ?>">
                                                                    <?php $__errorArgs = ['name', "edit$user->id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="invalid-feedback">
                                                                            <?php echo e($message); ?>

                                                                        </div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                                <div class="col">
                                                                    <label for="editAddress"
                                                                        class="form-label">Alamat</label>
                                                                    <input type="text"
                                                                        class="form-control <?php $__errorArgs = ['address', "edit$user->id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                        id="editAddress" name="address"
                                                                        value="<?php echo e($user->address); ?>">
                                                                    <?php $__errorArgs = ['address', "edit$user->id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="invalid-feedback">
                                                                            <?php echo e($message); ?>

                                                                        </div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                            <div class="row mb-3">
                                                                <div class="col">
                                                                    <label for="editEmail"
                                                                        class="form-label">Surel</label>
                                                                    <input type="email"
                                                                        class="form-control <?php $__errorArgs = ['email', "edit$user->id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                        id="editEmail" name="email"
                                                                        value="<?php echo e($user->email); ?>">
                                                                    <?php $__errorArgs = ['email', "edit$user->id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="invalid-feedback">
                                                                            <?php echo e($message); ?>

                                                                        </div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                                <div class="col">
                                                                    <label for="editPhone"
                                                                        class="form-label">Telepon</label>
                                                                    <input type="tel"
                                                                        class="form-control <?php $__errorArgs = ['phone', "edit$user->id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                        id="editPhone" name="phone"
                                                                        value="<?php echo e($user->phone); ?>">
                                                                    <?php $__errorArgs = ['phone', "edit$user->id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="invalid-feedback">
                                                                            <?php echo e($message); ?>

                                                                        </div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="mb-3">
                                                                    <label for="editImage" class="form-label">Unggah Foto
                                                                        Profil</label>
                                                                    <input type="hidden" name="oldImage"
                                                                        value="<?php echo e($user->image); ?>">
                                                                    <?php if($user->image): ?>
                                                                        <img src="<?php echo e(asset('storage/' . $user->image)); ?>"
                                                                            class="img-preview-edit mb-2 col-sm-3 d-block">
                                                                    <?php else: ?>
                                                                        <img class="img-preview-edit mb-2 col-sm-3">
                                                                    <?php endif; ?>
                                                                    <input
                                                                        class="form-control
                                                                    <?php $__errorArgs = ['image', "edit$user->id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                        type="file" id="editImage" name="image"
                                                                        onchange="previewImageEditUser()">
                                                                    <?php $__errorArgs = ['image', "edit$user->id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="invalid-feedback">
                                                                            <?php echo e($message); ?>

                                                                        </div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                            <label for="editLevel" class="form-label">Level</label>
                                                            <select class="form-select" id="editLevel" name="level_id"
                                                                disabled>
                                                                <option selected><?php echo e($user->level->name); ?></option>
                                                            </select>
                                                    </div>
                                                    <div
                                                        class="modal-footer d-flex flex-row-reverse justify-content-between">
                                                        <div>
                                                            <button type="button" class="btn btn-secondary me-1"
                                                                data-bs-dismiss="modal">Tutup</button>
                                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                                            </form>
                                                        </div>
                                                        <div>
                                                            <?php if($user->image): ?>
                                                                <form method="post"
                                                                    action="/data-master/pengguna/edit-foto/<?php echo e($user->id); ?>"
                                                                    class="d-inline"
                                                                    onsubmit="return confirm('Apakah Anda yakin untuk menghapus foto?')">
                                                                    <?php echo method_field('put'); ?>
                                                                    <?php echo csrf_field(); ?>
                                                                    <input type="hidden" name="image" value="">
                                                                    <input type="hidden" name="oldImage"
                                                                        value="<?php echo e($user->image); ?>">
                                                                    <button type="submit" class="btn btn-danger">
                                                                        Hapus Foto
                                                                    </button>
                                                                </form>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <a class="btn btn-sm btn-success text-light me-1 mb-2" data-bs-toggle="modal"
                                            data-bs-target="#modalChangePassword<?php echo e($user->id); ?>"><i
                                                class="bi bi-lock-fill"></i></a>
                                        <div class="modal fade" id="modalChangePassword<?php echo e($user->id); ?>"
                                            tabindex="-1" aria-labelledby="detailLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title fw-bold" id="exampleModalLabel">Edit Kata
                                                            Sandi
                                                        </h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form
                                                            action="/data-master/pengguna/edit-password/<?php echo e($user->id); ?>"
                                                            method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="row mb-3">
                                                                <div class="col">
                                                                    <label for="editCurrentPassword"
                                                                        class="form-label">Current Password</label>
                                                                    <input type="password"
                                                                        class="form-control <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                        id="editCurrentPassword" name="current_password">
                                                                    <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="invalid-feedback">
                                                                            <?php echo e($message); ?>

                                                                        </div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                            <div class="row mb-3">
                                                                <div class="col">
                                                                    <label for="editNewPassword" class="form-label">New
                                                                        Password</label>
                                                                    <input type="password"
                                                                        class="form-control <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                        id="editNewPassword" name="new_password">
                                                                    <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="invalid-feedback">
                                                                            <?php echo e($message); ?>

                                                                        </div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col">
                                                                    <label for="editNewPasswordConfirmation"
                                                                        class="form-label">Confirm New Password</label>
                                                                    <input type="password"
                                                                        class="form-control <?php $__errorArgs = ['new_password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                        id="editNewPasswordConfirmation"
                                                                        name="new_password_confirmation">
                                                                    <?php $__errorArgs = ['new_password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="invalid-feedback">
                                                                            <?php echo e($message); ?>

                                                                        </div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Tutup</button>
                                                        <button type="submit" class="btn btn-primary">Simpan</button>
                                                    </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <?php if(Auth::user()->level_id == '2'): ?>
                                        <?php if($user->level_id == '3'): ?>
                                            <form action="/data-master/pengguna/<?php echo e($user->id); ?>" method="post"
                                                class="d-inline"
                                                onsubmit="return confirm('Apakah Anda yakin untuk menghapus data <?php echo e($user->name); ?>?')">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="oldImage" value="<?php echo e($user->image); ?>">
                                                <button class="btn btn-danger btn-sm" type="submit">Hapus</button>
                                            </form>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Eka Priyanthara\Desktop\test\resources\views//data-master/pengguna.blade.php ENDPATH**/ ?>