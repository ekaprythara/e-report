<?php $__env->startSection('body'); ?>
    <div class="h1 fw-bold">
        Beranda</div>

    <div class="container-fluid rounded bg-white p-3 mb-3">
        <div class="row col-container d-flex justify-content-between align-items-center">
            <div class="col-wrap col-md-3">
                <div class="card text-white bg-primary h-100">
                    <div class="card-header fw-bold">Logistik Masuk</div>
                    <div class="card-body">
                        <h1 class="card-text">
                            <?php echo e($inboundLogistics); ?>

                        </h1>
                    </div>
                    <div class="card-footer d-grid gap-2 p-2">
                        <a href="/transaksi/logistik-masuk" type="button" class="btn btn-light d-flex justify-content-between align-items-center">
                            <span>Lihat</span>
                            <span><i class="bi bi-chevron-right"></i></span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-wrap col-md-3">
                <div class="card text-white bg-primary h-100">
                    <div class="card-header fw-bold">Logistik Keluar</div>
                    <div class="card-body">
                        <h1 class="card-text">
                            <?php echo e($outboundLogistics); ?>

                        </h1>
                    </div>
                    <div class="card-footer d-grid gap-2 p-2">
                        <a href="/transaksi/logistik-keluar" type="button" class="btn btn-light d-flex justify-content-between align-items-center">
                            <span>Lihat</span>
                            <span><i class="bi bi-chevron-right"></i></span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-wrap col-md-3">
                <div class="card text-white bg-danger h-100">
                    <div class="card-header fw-bold">Logistik Rusak</div>
                    <div class="card-body">
                        <h1 class="card-text">
                            9.999+
                        </h1>
                    </div>
                    <div class="card-footer d-grid gap-2 p-2">
                        <button type="button" class="btn btn-light d-flex justify-content-between align-items-center">
                            <span>Lihat</span>
                            <span><i class="bi bi-chevron-right"></i></span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="col-wrap col-md-3">
                <div class="card text-white bg-danger h-100">
                    <div class="card-header fw-bold">Logistik Kadaluarsa</div>
                    <div class="card-body">
                        <h1 class="card-text">
                            9.999+
                        </h1>
                    </div>
                    <div class="card-footer d-grid gap-2 p-2">
                        <button type="button" class="btn btn-light d-flex justify-content-between align-items-center">
                            <span>Lihat</span>
                            <span><i class="bi bi-chevron-right"></i></span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ekaprynthara/public_html/test/resources/views/beranda.blade.php ENDPATH**/ ?>