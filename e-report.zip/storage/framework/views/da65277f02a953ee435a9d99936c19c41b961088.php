<?php $__env->startSection('body'); ?>
    <div class="h1 fw-bold">Kedaluwarsa</div>
    <div class="container-fluid rounded p-3 bg-white mb-3">
        <div class="d-flex justify-content-end align-items-center mb-2">
            <button type="button" class="btn btn-success dropdown-toggle me-2" data-bs-toggle="dropdown" aria-expanded="false">
                Ekspor
            </button>
            <ul class="dropdown-menu">
                <li><a href="/laporan/kadaluarsa/ekspor/ods" class="dropdown-item">ODS</a></li>
                <li><a href="/laporan/kadaluarsa/ekspor/pdf" class="dropdown-item">PDF</a></li>
                <li><a href="/laporan/kadaluarsa/ekspor/xls" class="dropdown-item">XLS</a></li>
                <li><a href="/laporan/kadaluarsa/ekspor/xlsx" class="dropdown-item">XLSX</a></li>
            </ul>
            <a href="/laporan/kadaluarsa/print" type="button" class="btn btn-success">Cetak</a>
        </div>

        <div class="table-responsive p-0 pt-3 pb-3">
            <table id="tb-stokLogistik" class="table table-bordered table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Logistik</th>
                        <th>Penyuplai</th>
                        <th>Stok</th>
                        <th>Satuan</th>
                        <th>Kadaluarsa</th>
                        <th>Jenis Pengadaan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $inboundLogistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inboundLogistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($inboundLogistic->logistic->name); ?></td>
                            <td>
                                <?php echo e($inboundLogistic->supplier->name ?? $inboundLogistic->supplier); ?>

                            </td>
                            <td><?php echo e($inboundLogistic->stock); ?></td>
                            <td><?php echo e($inboundLogistic->logistic->standardUnit->name); ?></td>
                            <td><?php echo e($inboundLogistic->expiredDate); ?></td>
                            <td>
                                <?php echo e($inboundLogistic->logisticProcurement->name ?? $inboundLogistic->logisticProcurement); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ekaprynthara/public_html/test/resources/views//laporan/kadaluarsa.blade.php ENDPATH**/ ?>