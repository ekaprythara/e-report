<?php $__env->startSection('body'); ?>
    <div class="h1 fw-bold">Logistik Keluar</div>
    <div class="container rounded p-3 bg-white mb-3">
        <div class="d-flex justify-content-end align items center mb-2">
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                Tambah
            </button>
        </div>
        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title fw-bold" id="exampleModalLabel">Tambah Logistik Keluar</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="/logistik-masuk" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row mb-3">
                                <div class="col">
                                    <label for="outboundDate" class="form-label">Tanggal Keluar</label>
                                    <input type="text" class="form-control" id="outboundDate" name="outboundDate">
                                </div>
                                <div class="col">
                                    <label for="receiverUnit" class="form-label">Unit Penerima</label>
                                    <select class="form-select" id="receiverUnit" name="receiverUnit_id">
                                        <?php $__currentLoopData = $receiverUnits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receiverUnit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($receiverUnit->id); ?>"><?php echo e($receiverUnit->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col">
                                    <label for="receiver" class="form-label">Penerima</label>
                                    <select class="form-select" id="receiver" name="receiver_id">

                                    </select>
                                </div>
                            </div>
                            <label for="tb_logistikMasukModal" class="form-label">Logistik</label>
                            <div class="container-fluid border p-3 mb-3">
                                <table id="tb-modLogMasuk" class="table table-bordered table-striped table-sm"
                                    style="width:100%">
                                    <thead>
                                        <tr>
                                            <th></th>
                                            <th>Logistik</th>
                                            <th>Penyuplai</th>
                                            <th>Jumlah</th>
                                            <th>Satuan</th>
                                            <th>Tanggal Kadaluarsa</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    </tbody>
                                </table>
                            </div>
                            <label for="description" class="form-label">Keterangan</label>
                            <textarea class="form-control mb-3" id="description" name="description"></textarea>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                <button type="submit" class="btn btn-primary">Tambah</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Table -->
        <table id="tb-logistikKeluar" class="table table-bordered table-striped" style="width:100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Tanggal Keluar</th>
                    <th>Logistik</th>
                    <th>Penyuplai</th>
                    <th>Unit Penerima</th>
                    <th>Penerima</th>
                    <th>Jumlah</th>
                    <th>Satuan</th>
                    <th>Keterangan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $outboundLogistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outboundLogistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>
                            <form action="/logistik-keluar/<?php echo e($outboundLogistic->id); ?>" method="post"
                                class="d-inline"
                                onsubmit="return confirm('Apakah Anda yakin untuk menghapus data ini?')">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger btn-sm" type="submit">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pyzakke/public_html/test/resources/views//logistik-keluar.blade.php ENDPATH**/ ?>