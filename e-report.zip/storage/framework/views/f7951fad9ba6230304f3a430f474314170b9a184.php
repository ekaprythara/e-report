<?php $__env->startSection('body'); ?>
<div class="h1 fw-bold">Laporan Stok Opname</div>
<div class="container rounded p-3 bg-white mb-3">
    <div class="mb-3">Stok Opname Bulan ...</div>
    <table id="lp-stok-opname" class="table table-bordered table-striped" style="width:100%">
        <thead>
            <th>No.</th>
            <th>Logistik</th>
            <th>Jenis Logistik</th>
            <th>Sisa Bulan Lalu</th>
            <th>Masuk</th>
            <th>Keluar</th>
            <th>Sisa</th>
            <th>Satuan</th>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pyzakke/public_html/test/resources/views/lp-stok-opname.blade.php ENDPATH**/ ?>