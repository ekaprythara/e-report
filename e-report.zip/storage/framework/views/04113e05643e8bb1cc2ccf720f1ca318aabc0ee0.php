
<nav class="navbar fixed-top navbar-expand navbar-dark bg-dark">
    <div class="container-fluid">
        <button class="btn btn-dark btn-lg" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample"
            aria-controls="offcanvasExample">
            <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand fw-bold me-auto ms-2">E-REPORT LOGISTIK</a>
        <ul class="navbar-nav">
            <li class="nav-item dropdown">
                <a href="#" class="d-flex align-items-center nav-link text-decoration-none dropdown-toggle"
                    id="dropdownUser2" data-bs-toggle="dropdown" aria-expanded="false">
                    <img src="https://github.com/mdo.png" alt="" width="32" height="32" class="rounded-circle me-2">
                    <strong class="me-1">Admin One</strong>
                </a>
                <ul class="dropdown-menu dropdown-menu-dark dropdown-menu-end" aria-labelledby="navbarDropdownMenuLink">
                    <li><button type="button" class="dropdown-item btn btn-primary" data-bs-toggle="modal"
                            data-bs-target="#showProfile">
                            Profil
                        </button>
                    </li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <li><a class="dropdown-item" href="#">Keluar</a></li>
                </ul>
            </li>
        </ul>
    </div>
</nav>


<div class="offcanvas offcanvas-start" style="width: 250px" tabindex="-1" id="offcanvasExample"
    aria-labelledby="offcanvasExampleLabel">
    <div class="offcanvas-body p-2" style="background-color: #e9ecef" id="collapse">
        <ul class="nav nav-pills sidebar-menu-macos flex-column">
            <li class="nav-item">
                <a href="/beranda"
                    class="nav-link d-flex justify-content-start <?php echo e(Request::is('beranda') ? 'active' : 'link-dark'); ?>"
                    aria-current="page">
                    <span><i class="bi bi-house-door me-3"></i>Beranda</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link link-dark d-flex justify-content-between" data-bs-toggle="collapse"
                    href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                    <span><i class="bi bi-hdd me-3"></i>Data Master</span>
                    <span class="rotate-chevron"><i class="bi bi-chevron-down"></i></span>
                </a>
                <div class="collapse collapse-menu-macos" id="collapseExample" data-bs-parent="#collapse">
                    <div>
                        <ul class="nav nav-pills sidebar-menu-macos d-flex flex-column">
                            <li>
                                <a href="/data-master/level"
                                    class="nav-link d-flex justify-content-start <?php echo e(Request::is('level') ? 'active' : 'link-dark'); ?>">
                                    <span class="ms-3">Level</span>
                                </a>
                            </li>
                            <li>
                                <a href="/data-master/pengguna"
                                    class="nav-link d-flex justify-content-start <?php echo e(Request::is('pengguna') ? 'active' : 'link-dark'); ?>">
                                    <span class="ms-3">Pengguna</span>
                                </a>
                            </li>
                            <li>
                                <a href="/data-master/unit-penerima"
                                    class="nav-link d-flex justify-content-start <?php echo e(Request::is('unit-penerima') ? 'active' : 'link-dark'); ?>">
                                    <span class="ms-3">Unit Penerima</span>
                                </a>
                            </li>
                            <li>
                                <a href="/data-master/penerima"
                                    class="nav-link d-flex justify-content-start <?php echo e(Request::is('penerima') ? 'active' : 'link-dark'); ?>">
                                    <span class="ms-3">Penerima</span>
                                </a>
                            </li>
                            <li>
                                <a href="/data-master/jenis-pengadaan"
                                    class="nav-link d-flex justify-content-start <?php echo e(Request::is('jenis-pengadaan') ? 'active' : 'link-dark'); ?>">
                                    <span class="ms-3">Jenis Pengadaan</span>
                                </a>
                            </li>
                            <li>
                                <a href="/data-master/jenis-logistik"
                                    class="nav-link d-flex justify-content-start <?php echo e(Request::is('jenis-logistik') ? 'active' : 'link-dark'); ?>">
                                    <span class="ms-3">Jenis Logistik</span>
                                </a>
                            </li>
                            <li>
                                <a href="/data-master/satuan"
                                    class="nav-link d-flex justify-content-start <?php echo e(Request::is('satuan') ? 'active' : 'link-dark'); ?>">
                                    <span class="ms-3">Satuan</span>
                                </a>
                            </li>
                            <li>
                                <a href="/data-master/logistik"
                                    class="nav-link d-flex justify-content-start <?php echo e(Request::is('logistik') ? 'active' : 'link-dark'); ?>">
                                    <span class="ms-3">Logistik</span>
                                </a>
                            </li>
                            <li>
                                <a href="/data-master/penyuplai"
                                    class="nav-link d-flex justify-content-start <?php echo e(Request::is('penyuplai') ? 'active' : 'link-dark'); ?>">
                                    <span class="ms-3">Penyuplai</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </li>
            <li class="nav-item">
                <a href="/logistik-masuk"
                    class="nav-link d-flex justify-content-start <?php echo e(Request::is('logistik-masuk') ? 'active' : 'link-dark'); ?>">
                    <span><i class="bi bi-box-arrow-in-right me-3"></i>Logistik Masuk</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="/stok-logistik"
                    class="nav-link d-flex justify-content-start <?php echo e(Request::is('stok-logistik') ? 'active' : 'link-dark'); ?>">
                    <span><i class="bi bi-box-seam me-3"></i>Stok Logistik</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="/logistik-keluar"
                    class="nav-link d-flex justify-content-start <?php echo e(Request::is('logistik-keluar') ? 'active' : 'link-dark'); ?>">
                    <span><i class="bi bi-box-arrow-right me-3"></i>Logistik Keluar</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link link-dark d-flex justify-content-between" data-bs-toggle="collapse"
                    href="#collapseExample2" role="button" aria-expanded="false" aria-controls="collapseExample2">
                    <span><i class="bi bi-file-earmark me-3"></i>Laporan</span>
                    <span class="rotate-chevron"><i class="bi bi-chevron-down"></i></span>
                </a>
                <div class="collapse collapse-menu-macos" id="collapseExample2" data-bs-parent="#collapse">
                    <div>
                        <ul class="nav nav-pills sidebar-menu-macos d-flex flex-column">
                            <li>
                                <a href="/laporan/logistik-masuk"
                                    class="nav-link d-flex justify-content-start <?php echo e(Request::is('laporan/logistik-masuk') ? 'active' : 'link-dark'); ?>">
                                    <span class="ms-3">Logistik Masuk</span>
                                </a>
                            </li>
                            <li>
                                <a href="/laporan/logistik-keluar"
                                    class="nav-link d-flex justify-content-start <?php echo e(Request::is('laporan/logistik-keluar') ? 'active' : 'link-dark'); ?>">
                                    <span class="ms-3">Logistik Keluar</span>
                                </a>
                            </li>
                            <li>
                                <a href="/laporan/stok-opname"
                                    class="nav-link d-flex justify-content-start <?php echo e(Request::is('laporan/stok-opname') ? 'active' : 'link-dark'); ?>">
                                    <span class="ms-3">Stok Opname</span>
                                </a>
                            </li>
                            <li>
                                <a href="/laporan/kartu-stok"
                                    class="nav-link d-flex justify-content-start <?php echo e(Request::is('laporan/kartu-stok') ? 'active' : 'link-dark'); ?>">
                                    <span class="ms-3">Kartu Stok</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</div>

<!-- Modal Profil -->
<div class="modal fade" id="showProfile" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Profil Admin One</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col d-flex flex-column justify-content-center align-items-center">
                        <img src="https://github.com/mdo.png" alt="" width="180" height="180"
                            class="rounded-circle me-2 mb-3">
                    </div>
                    <div class="col d-flex flex-column justify-content-start">
                        <input type="text" class="form-control mb-2" value="adminone" disabled>
                        <input type="text" class="form-control mb-2" value="Admin One" disabled>
                        <input type="text" class="form-control mb-2" value="Admin" disabled>
                        <input type="text" class="form-control" value="085700000001" disabled>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/pyzakke/public_html/test/resources/views//partials/navbar.blade.php ENDPATH**/ ?>