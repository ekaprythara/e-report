<?php $__env->startSection('body'); ?>
<div class="h1 fw-bold">Beranda</div>
<button type="button" class="btn btn-primary" data-bs-toggle="modal"
            data-bs-target="#exampleModal">Tambah</button>
<div class="card" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="false">


            <div class="card-body">
                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                <button type="button" class="btn btn-primary">Tambah</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pyzakke/public_html/test/resources/views/beranda.blade.php ENDPATH**/ ?>