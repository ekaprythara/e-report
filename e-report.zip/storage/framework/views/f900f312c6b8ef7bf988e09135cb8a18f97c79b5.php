<?php $__env->startSection('body'); ?>
    <div class="h1 fw-bold">Stok Logistik</div>
    <div class="container rounded p-3 bg-white mb-3">
        <table id="tb-stokLogistik" class="table table-bordered table-striped" style="width:100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Logistik</th>
                    <th>Total</th>
                    <th>Satuan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $logistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($logistic->name); ?></td>
                        <td></td>
                        <td><?php echo e($logistic->standardUnit); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pyzakke/public_html/test/resources/views/stok-logistik.blade.php ENDPATH**/ ?>