<?php $__env->startSection('body'); ?>
    <div class="h1 fw-bold">Pengguna</div>
    <div class="container rounded p-3 bg-white mb-3">
        <div class="d-flex justify-content-end align items center mb-2">
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                Tambah
            </button>
        </div>

        
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title fw-bold" id="exampleModalLabel">Tambah Pengguna</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="/data-master/pengguna" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row mb-3">
                                <div class="col">
                                    <label for="addUsername" class="form-label">Nama Pengguna</label>
                                    <input type="text" class="form-control" id="addUsername" name="username">
                                </div>
                                <div class="col">
                                    <label for="addPassword" class="form-label">Kata Sandi</label>
                                    <input type="password" class="form-control" id="addPassword" name="password">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col">
                                    <label for="addName" class="form-label">Nama Lengkap</label>
                                    <input type="text" class="form-control" id="addName" name="name">
                                </div>
                                <div class="col">
                                    <label for="addAddress" class="form-label">Alamat</label>
                                    <input type="text" class="form-control" id="addAddress" name="address">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col">
                                    <label for="addEmail" class="form-label">Surel</label>
                                    <input type="email" class="form-control" id="addEmail" name="email">
                                </div>
                                <div class="col">
                                    <label for="addPhone" class="form-label">Telepon</label>
                                    <input type="tel" class="form-control" id="addPhone" name="phone">
                                </div>
                            </div>
                            <label for="addLevel" class="form-label">Level</label>
                            <select class="form-select" id="addLevel" name="level_id" disabled>
                                <option selected>Operator</option>
                            </select>
                            <input type="hidden" name="level_id" value="2">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>

        <?php if(session()->has('create')): ?>
            <div class="alert alert-success" id="success-alert" role="alert">
                <?php echo e(session('create')); ?>

            </div>
        <?php elseif(session()->has('update')): ?>
            <div class="alert alert-warning" id="warning-alert" role="alert">
                <?php echo e(session('update')); ?>

            </div>
        <?php elseif(session()->has('delete')): ?>
            <div class="alert alert-danger" id="danger-alert" role="alert">
                <?php echo e(session('delete')); ?>

            </div>
        <?php endif; ?>

        
        <table id="tb-pengguna" class="table table-responsive table-bordered table-striped table-hover table-lg"
            style="width:100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Pengguna</th>
                    <th>Alamat</th>
                    <th>Surel</th>
                    <th>Telepon</th>
                    <th>Level</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->address); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->phone); ?></td>
                        <td><?php echo e($user->level->name); ?></td>
                        <td class="mb-1">
                            
                            <a class="btn btn-sm btn-warning text-light me-1" data-bs-toggle="modal"
                                data-bs-target="#modalEdit<?php echo e($user->id); ?>">Edit</a>
                            <div class="modal fade" id="modalEdit<?php echo e($user->id); ?>" tabindex="-1"
                                aria-labelledby="detailLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title fw-bold" id="detailLabel">Edit</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="/data-master/pengguna/<?php echo e($user->id); ?>" method="post">
                                                <?php echo method_field('put'); ?>
                                                <?php echo csrf_field(); ?>
                                                <div class="row mb-3">
                                                    <div class="col">
                                                        <label for="editUsername<?php echo e($user->id); ?>"
                                                            class="form-label">Nama
                                                            Pengguna</label>
                                                        <input type="text" class="form-control"
                                                            id="editUsername<?php echo e($user->id); ?>"
                                                            value="<?php echo e($user->username); ?>" name="username">
                                                    </div>
                                                    <div class="col">
                                                        <label for="editPassword<?php echo e($user->id); ?>"
                                                            class="form-label">Kata
                                                            Sandi</label>
                                                        <input type="password" class="form-control"
                                                            id="editPassword<?php echo e($user->id); ?>"
                                                            value="<?php echo e($user->password); ?>" name="password">
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <div class="col">
                                                        <label for="editName<?php echo e($user->id); ?>"
                                                            class="form-label">Nama
                                                            Lengkap</label>
                                                        <input type="text" class="form-control"
                                                            id="editName<?php echo e($user->id); ?>" value="<?php echo e($user->name); ?>"
                                                            name="name">
                                                    </div>
                                                    <div class="col">
                                                        <label for="editAddress<?php echo e($user->id); ?>"
                                                            class="form-label">Alamat</label>
                                                        <input type="text" class="form-control"
                                                            id="editAddress<?php echo e($user->id); ?>"
                                                            value="<?php echo e($user->address); ?>" name="address">
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <div class="col">
                                                        <label for="editEmail<?php echo e($user->id); ?>"
                                                            class="form-label">Surel</label>
                                                        <input type="email" class="form-control"
                                                            id="editEmail<?php echo e($user->id); ?>" value="<?php echo e($user->email); ?>"
                                                            name="email">
                                                    </div>
                                                    <div class="col">
                                                        <label for="editPhone<?php echo e($user->id); ?>"
                                                            class="form-label">Telepon</label>
                                                        <input type="tel" class="form-control"
                                                            id="editPhone<?php echo e($user->id); ?>" value="<?php echo e($user->phone); ?>"
                                                            name="phone">
                                                    </div>
                                                </div>
                                                <label for="editLevel<?php echo e($user->id); ?>"
                                                    class="form-label">Level</label>
                                                <select class="form-select" id="editLevel<?php echo e($user->id); ?>"
                                                    name="level_id" disabled>
                                                    <?php if($user->level->id == '1'): ?>
                                                        <option value='1' selected>
                                                            Admin
                                                        </option>
                                                    <?php else: ?>
                                                        <option value='2' selected>
                                                            Operator
                                                        </option>
                                                    <?php endif; ?>
                                                </select>
                                                <?php if($user->level_id == '1'): ?>
                                                    <input type="hidden" name="level_id" value="1">
                                                <?php else: ?>
                                                    <input type="hidden" name="level_id" value="2">
                                                <?php endif; ?>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Tutup</button>
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                            <form action="/data-master/pengguna/<?php echo e($user->id); ?>" method="post" class="d-inline"
                                onsubmit="return confirm('Apakah Anda yakin untuk menghapus data <?php echo e($user->name); ?>?')">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger btn-sm" type="submit">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pyzakke/public_html/test/resources/views//data-master/pengguna.blade.php ENDPATH**/ ?>