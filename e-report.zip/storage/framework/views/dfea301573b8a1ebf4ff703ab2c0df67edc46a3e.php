<?php $__env->startSection('body'); ?>
    <div class="container row text-center justify-content-center">
        <div class="col-md-4">
            <img class="mb-3" src="img/logo-bpbd-provinsi-bali.png" alt="" width="200" height="200">
            <h1 class="h3 mb-3 fw-normal">Sistem Informasi E-Report Logistik</h1>
            <form>
                <div class="form-floating mb-1">
                    <input type="text" class="form-control" id="username" placeholder="">
                    <label for="username">Nama pengguna</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="password" class="form-control" id="password" placeholder="">
                    <label for="password">Kata Sandi</label>
                </div>
                <button class="w-100 btn btn-primary" type="submit">Masuk</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('/layouts/masuk', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pyzakke/public_html/test/resources/views//masuk/index.blade.php ENDPATH**/ ?>