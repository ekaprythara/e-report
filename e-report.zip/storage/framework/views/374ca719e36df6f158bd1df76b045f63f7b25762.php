<!DOCTYPE html>
<html>

<head>
</head>

<body>
    <table>
        <tr>
            <td colspan="7" style="text-align: center;">
                <b>PEMERINTAH PROVINSI BALI</b>
            </td>
        </tr>
        <tr>
            <td colspan="7" style="text-align: center;">
                <b>Badan Penanggulangan Bencana Daerah</b>
            </td>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr>
            <td colspan="7" style="text-align: center;">
                <b>LAPORAN KADALUARSA</b>
            </td>
        </tr>
    </table>

    <table>
        <thead>
            <tr>
                <th><b>No.</b></th>
                <th><b>Logistik</b></th>
                <th><b>Penyuplai</b></th>
                <th><b>Stok</b></th>
                <th><b>Satuan</b></th>
                <th><b>Kadaluarsa</b></th>
                <th><b>Jenis Pengadaan</b></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $inboundLogistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inboundLogistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($inboundLogistic->logistic->name); ?></td>
                    <td>
                        <?php echo e($inboundLogistic->supplier->name ?? $inboundLogistic->supplier); ?>

                    </td>
                    <td><?php echo e($inboundLogistic->stock); ?></td>
                    <td><?php echo e($inboundLogistic->logistic->standardUnit->name); ?></td>
                    <td><?php echo e($inboundLogistic->expiredDate); ?></td>
                    <td>
                        <?php echo e($inboundLogistic->logisticProcurement->name ?? $inboundLogistic->logisticProcurement); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr></tr>
            <tr></tr>
            <tr>
                <td colspan="7" style="text-align: right;">
                    <b>
                        Denpasar,
                        <?php
                            $date = Carbon\Carbon::now()->locale('id');
                            $date->settings(['formatFunction' => 'translatedFormat']);
                            echo $date->format('d F Y');
                        ?>
                    </b>
                </td>
            </tr>
            <tr>
                <td colspan="7" style="text-align: right;">
                    <b>
                        <?php echo e(Auth::user()->level->name); ?>

                        <?php if(Auth::user()->level_id == '1'): ?>
                            Kedaruratan dan Logistik
                        <?php else: ?>
                            Logistik dan Peralatan
                        <?php endif; ?>
                    </b>
                </td>
            </tr>
            <tr>
                <td colspan="7" rowspan="4">
                </td>
            </tr>
            <tr></tr>
            <tr></tr>
            <tr></tr>
            <tr>
                <td colspan="7" style="text-align: right; vertical-align:top; text-decoration:underline;">
                    <b>
                        <?php echo e(Auth::user()->name); ?>

                    </b>
                </td>
            </tr>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH /home/ekaprynthara/public_html/test/resources/views//ekspor/kadaluarsa/excel.blade.php ENDPATH**/ ?>