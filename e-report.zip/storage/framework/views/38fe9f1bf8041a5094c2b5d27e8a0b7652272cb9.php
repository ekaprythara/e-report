<!DOCTYPE html>
<html>

<head>
    <style>
        .aksara {
            font-family: 'bali simbar dwijendra';
            font-style: normal;
            font-weight: 400;
            padding-top: 7px;
            padding-bottom: 15px;
        }

        .text-right {
            text-align: right;
        }

        .page-break {
            page-break-before: auto;
        }

        body {
            font-family: Arial, Helvetica, sans-serif;
        }

        #head {
            width: 100%;
            line-height: 5px;
        }

        #head tr td {
            text-align: center;
            font-size: small;
        }

        #head tr td hr {
            width: 90%;
        }

        #title {
            text-align: center;
            line-height: 2px;
            padding: 5px 5px 5px;
        }

        #body {
            border-collapse: collapse;
            width: 100%;
            font-size: 10pt;
            color: black;
        }

        #body td,
        #body th {
            padding: 5px;
            border: 1px solid black;
        }

        #body tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #body th {
            padding-top: 10px;
            padding-bottom: 10px;
            text-align: left;
            background-color: #FEB139;
            color: black;
        }

        #foot {
            margin-top: 20px;
            font-size: small;
            text-align: left;
            float: right;
            line-height: 5px;
        }
    </style>
</head>

<body>
    <div class="page-break">
        <table id="head">
            <tr>
                <td>
                    <img src="<?php echo e(public_path('/img/logo-pemprov.png')); ?>" alt="Logo Pemprov Bali" width="150"
                        height="150">
                </td>
                <td>
                    <h2 class="aksara">p) m) ri nÓ ;¾ ¿ epÉo pi nŠi ¿ b lø</h2>
                    <h2>PEMERINTAH PROVINSI BALI</h2>
                    <h2 class="aksara">b d n/¾ ¿ p) n \á¡ l \ n/¾ ¿ ¿ b) ZÇÿ n ¿ ¿ d6 r ;¾</h2>
                    <h2>BADAN PENANGGULANGAN BENCANA DAERAH</h2>
                    <p>Jalan D.I. Panjaitan No. 6 Denpasar - Bali 80235</p>
                    <p>Telp: 0361-245397, Fax: 0361-245395</p>
                    <p>Laman: <a href="http://www.bpbd.baliprov.go.id/">bpbd.baliprov.go.id</a>, Surel:
                        bpbd@baliprov.go.id
                    </p>
                </td>
            </tr>
        </table>
        <hr>
        <div id="title">
            <h3>LAPORAN LOGISTIK KELUAR</h3>
            <h4>
                <?php
                    $start = Carbon\Carbon::parse($from)->locale('id');
                    $start->settings(['formatFunction' => 'translatedFormat']);

                    $end = Carbon\Carbon::parse($to)->locale('id');
                    $end->settings(['formatFunction' => 'translatedFormat']);
                ?>
                <?php if($start == $end): ?>
                    <?php
                        echo $start->format('d F Y');
                    ?>
                <?php else: ?>
                    <?php
                        echo $start->format('d F Y') . ' - ' . $end->format('d F Y');
                    ?>
                <?php endif; ?>
            </h4>
        </div>
    </div>

    <table id="body">
        <thead>
            <tr>
                <th>No.</th>
                <th>Tanggal Keluar</th>
                <th>Logistik</th>
                <th>Penyuplai</th>
                <th>Unit Penerima</th>
                <th>Penerima</th>
                <th>Jumlah</th>
                <th>Satuan</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $outboundLogistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outboundLogistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-right"><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($outboundLogistic->outboundDate); ?></td>
                    <td><?php echo e($outboundLogistic->inboundLogistic->logistic->name); ?></td>
                    <td>
                        <?php echo e($outboundLogistic->inboundLogistic->supplier->name ?? $outboundLogistic->inboundLogistic->supplier); ?>

                    </td>
                    <td>
                        <?php echo e($outboundLogistic->receiver->receiverUnit->name ?? ''); ?>

                    </td>
                    <td>
                        <?php if(isset($outboundLogistic->receiver->receiverUnit->name)): ?>
                            <?php echo e($outboundLogistic->receiver->name); ?>

                        <?php endif; ?>
                    </td>
                    <td class="text-right"><?php echo e($outboundLogistic->quantity); ?></td>
                    <td><?php echo e($outboundLogistic->inboundLogistic->logistic->standardUnit->name); ?></td>
                    <td><?php echo e($outboundLogistic->description); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="page-break">
        <table id="foot">
            <tr>
                <td>
                    <p>Denpasar,
                        <?php
                            $date = Carbon\Carbon::now()->locale('id');
                            $date->settings(['formatFunction' => 'translatedFormat']);
                            echo $date->format('d F Y');
                        ?>
                    </p>
                    <p>
                        <?php echo e(Auth::user()->level->name); ?>

                        <?php if(Auth::user()->level_id == '1'): ?>
                            Kedaruratan dan Logistik
                        <?php else: ?>
                            Logistik dan Peralatan
                        <?php endif; ?>
                    </p>
                    <p>BPBD Provinsi Bali</p>
                    <p></p>
                    <p></p>
                    <p></p>
                    <p></p>
                    <p></p>
                    <strong><u><?php echo e(Auth::user()->name); ?></u></strong>
                </td>
            </tr>
        </table>
    </div>
</body>

</html>
<?php /**PATH /home/ekaprynthara/public_html/test/resources/views//ekspor/logistik-keluar/pdf.blade.php ENDPATH**/ ?>