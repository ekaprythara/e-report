<!DOCTYPE html>
<html>

<head>
</head>

<body>
    <table>
        <tr>
            <td colspan="9" style="text-align: center;">
                <b>PEMERINTAH PROVINSI BALI</b>
            </td>
        </tr>
        <tr>
            <td colspan="9" style="text-align: center;">
                <b>Badan Penanggulangan Bencana Daerah</b>
            </td>
        </tr>
        <tr></tr>
        <tr>
            <td colspan="9" style="text-align: center;">
                <b>LAPORAN LOGISTIK KELUAR</b>
            </td>
        </tr>
        <tr>
            <td colspan="9" style="text-align: center;">
                <b><?php
                    $start = Carbon\Carbon::parse($from)->locale('id');
                    $start->settings(['formatFunction' => 'translatedFormat']);
                    echo $start->format('d F Y');
                ?> -
                    <?php
                        $end = Carbon\Carbon::parse($to)->locale('id');
                        $end->settings(['formatFunction' => 'translatedFormat']);
                        echo $end->format('d F Y');
                    ?></b>
            </td>
        </tr>
    </table>

    <table border="1px solid">
        <thead>
            <tr>
                <th><b>No.</b></th>
                <th><b>Tanggal Keluar</b></th>
                <th><b>Logistik</b></th>
                <th><b>Penyuplai</b></th>
                <th><b>Unit Penerima</b></th>
                <th><b>Penerima</b></th>
                <th><b>Jumlah</b></th>
                <th><b>Satuan</b></th>
                <th><b>Keterangan</b></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $outboundLogistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outboundLogistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($outboundLogistic->outboundDate); ?></td>
                    <td><?php echo e($outboundLogistic->inboundLogistic->logistic->name); ?></td>
                    <td>
                        <?php echo e($outboundLogistic->inboundLogistic->supplier->name ?? $outboundLogistic->inboundLogistic->supplier); ?>

                    </td>
                    <td>
                        <?php echo e($outboundLogistic->receiver->receiverUnit->name ?? ''); ?>

                    </td>
                    <td>
                        <?php if(isset($outboundLogistic->receiver->receiverUnit->name)): ?>
                            <?php echo e($outboundLogistic->receiver->name); ?>

                        <?php endif; ?>
                    </td>
                    <td><?php echo e($outboundLogistic->quantity); ?></td>
                    <td><?php echo e($outboundLogistic->inboundLogistic->logistic->standardUnit->name); ?></td>
                    <td><?php echo e($outboundLogistic->description); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </tbody>
    </table>
</body>

</html>
<?php /**PATH /home/ekaprynthara/public_html/test/resources/views//ekspor/logistik-keluar/excel.blade.php ENDPATH**/ ?>