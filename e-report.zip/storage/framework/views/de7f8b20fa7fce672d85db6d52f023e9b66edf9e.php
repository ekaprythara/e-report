<!DOCTYPE html>
<html>

<head>
    <style>
        body {
            font-family: sans-serif;
        }

        #customers {
            border-collapse: collapse;
            width: 100%;
        }

        #customers td,
        #customers th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        #customers tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #313335;
            color: white;
        }
    </style>
</head>

<body>
    <table id="customers">
        <thead>
            <tr>
                <th>No.</th>
                <th>Tanggal Masuk</th>
                <th>Logistik</th>
                <th>Penyuplai</th>
                <th>Jumlah</th>
                <th>Satuan</th>
                <th>Tanggal Kadaluarsa</th>
                <th>Jenis Pengadaan</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $inboundLogistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inboundLogistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($inboundLogistic->inboundDate); ?></td>
                    <td><?php echo e($inboundLogistic->logistic->name); ?></td>
                    <td>
                        <?php echo e($inboundLogistic->supplier->name ?? $inboundLogistic->supplier); ?>

                    </td>
                    <td><?php echo e($inboundLogistic->amount); ?></td>
                    <td><?php echo e($inboundLogistic->logistic->standardUnit->name); ?></td>
                    <td><?php echo e($inboundLogistic->expiredDate); ?></td>
                    <td>
                        <?php echo e($inboundLogistic->logisticProcurement->name ?? $inboundLogistic->logisticProcurement); ?>

                    </td>
                    <td><?php echo e($inboundLogistic->description); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH /home/ekaprynthara/public_html/test/resources/views//ekspor/logistik-masuk.blade.php ENDPATH**/ ?>