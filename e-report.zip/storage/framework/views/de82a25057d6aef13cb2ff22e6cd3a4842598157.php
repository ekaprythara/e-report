<!DOCTYPE html>
<html>

<head>
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
        }

        #customers {
            border-collapse: collapse;
            width: 100%;
        }

        #customers td,
        #customers th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        #customers tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #313335;
            color: white;
        }
    </style>
</head>

<body>
    <table id="customers">
        <thead>
            <tr>
                <th>No.</th>
                <th>Tanggal Keluar</th>
                <th>Logistik</th>
                <th>Penyuplai</th>
                <th>Unit Penerima</th>
                <th>Penerima</th>
                <th>Jumlah</th>
                <th>Satuan</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $outboundLogistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outboundLogistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($outboundLogistic->outboundDate); ?></td>
                    <td><?php echo e($outboundLogistic->inboundLogistic->logistic->name); ?></td>
                    <td>
                        <?php echo e($outboundLogistic->inboundLogistic->supplier->name ?? $outboundLogistic->inboundLogistic->supplier); ?>

                    </td>
                    <td>
                        <?php echo e($outboundLogistic->receiver->receiverUnit->name ?? $outboundLogistic->receiver); ?>

                    </td>
                    <td>
                        <?php echo e($outboundLogistic->receiver->name ?? $outboundLogistic->receiver); ?>

                    </td>
                    <td><?php echo e($outboundLogistic->quantity); ?></td>
                    <td><?php echo e($outboundLogistic->inboundLogistic->logistic->standardUnit->name); ?></td>
                    <td><?php echo e($outboundLogistic->description); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH /home/ekaprynthara/public_html/test/resources/views//ekspor/logistik-keluar.blade.php ENDPATH**/ ?>