<?php $__env->startSection('body'); ?>
    <div class="h1 fw-bold">Logistik Keluar</div>
    <div class="container rounded p-3 bg-white mb-3">
        <div class="d-flex justify-content-end align items center mb-2">
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                Tambah
            </button>
        </div>
        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title fw-bold" id="exampleModalLabel">Tambah Logistik Keluar</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="/logistik-masuk" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row mb-3">
                                <div class="col">
                                    <label for="inboundDate" class="form-label">Tanggal Keluar</label>
                                    <input type="text" class="form-control" id="inboundDate" name="inboundDate">
                                </div>
                                <div class="col">
                                    <label for="logMasukPenyuplai" class="form-label">Unit Penerima</label>
                                    <select class="form-select" id="logMasukPenyuplai" name="supplier_id">

                                    </select>
                                </div>
                                <div class="col">
                                    <label for="logMasukJenisPengadaan" class="form-label">Penerima</label>
                                    <select class="form-select" id="logMasukJenisPengadaan"
                                        name="logisticProcurement_id">

                                    </select>
                                </div>
                            </div>
                            <label for="tb_logistikMasukModal" class="form-label">Logistik</label>
                            <div class="container-fluid border p-3 mb-3">
                                <table id="tb-modLogMasuk" class="table table-bordered table-striped table-sm"
                                    style="width:100%">
                                    <thead>
                                        <tr>
                                            <th></th>
                                            <th>Logistik</th>
                                            <th>Jumlah</th>
                                            <th>Satuan</th>
                                            <th>Tanggal Kadaluarsa</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    </tbody>
                                </table>
                            </div>
                            <label for="description" class="form-label">Keterangan</label>
                            <textarea class="form-control mb-3" id="description" name="description"></textarea>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                <button type="submit" class="btn btn-primary">Tambah</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Table -->
        <table id="tb-logistikKeluar" class="table table-bordered table-striped" style="width:100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Tanggal Keluar</th>
                    <th>Logistik</th>
                    <th>Penyuplai</th>
                    <th>Unit Penerima</th>
                    <th>Penerima</th>
                    <th>Jumlah</th>
                    <th>Satuan</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tbody>

            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pyzakke/public_html/test/resources/views/logistik-keluar.blade.php ENDPATH**/ ?>