<?php $__env->startSection('body'); ?>
    <div class="h1 fw-bold">Logistik Keluar</div>
    <div class="container-fluid rounded p-3 bg-white mb-3">
        <div class="d-flex justify-content-end align items center mb-2">
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                Tambah
            </button>
        </div>
        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title fw-bold" id="exampleModalLabel">Tambah Logistik Keluar</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="/logistik-keluar" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row mb-3">
                                <div class="col">
                                    <label for="outboundDate" class="form-label">Tanggal Keluar</label>
                                    <input type="date" class="form-control" id="outboundDate" name="outboundDate" value="<?php echo e(now()->toDateString()); ?>">
                                </div>
                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dropdown')->html();
} elseif ($_instance->childHasBeenRendered('u5Jv5tL')) {
    $componentId = $_instance->getRenderedChildComponentId('u5Jv5tL');
    $componentTag = $_instance->getRenderedChildComponentTagName('u5Jv5tL');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('u5Jv5tL');
} else {
    $response = \Livewire\Livewire::mount('dropdown');
    $html = $response->html();
    $_instance->logRenderedChild('u5Jv5tL', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            </div>
                            <label for="tb_logistikMasukModal" class="form-label">Logistik</label>
                            <div class="container-fluid border p-3 mb-3">
                                <table id="tb-modLogMasuk" class="table table-bordered table-striped table-sm"
                                    style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Logistik</th>
                                            <th>Penyuplai</th>
                                            <th>Stok</th>
                                            <th>Satuan</th>
                                            <th>Tanggal Kadaluarsa</th>
                                            <th>Jumlah</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $inboundLogistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inboundLogistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <input class="form-check-input" type="checkbox" id="flexCheckDefault"
                                                name="inboundLogistic_id" value="<?php echo e($inboundLogistic->id); ?>">
                                            </td>
                                            <td><?php echo e($inboundLogistic->logistic->name); ?></td>
                                            <td><?php echo e($inboundLogistic->supplier->name); ?></td>
                                            <td><?php echo e($inboundLogistic->amount); ?></td>
                                            <td><?php echo e($inboundLogistic->logistic->standardUnit->name); ?></td>
                                            <td><?php echo e($inboundLogistic->expiredDate); ?></td>
                                            <td>
                                                <input type="text" class="form-control" name="quantity" disabled>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <label for="description" class="form-label">Keterangan</label>
                            <textarea class="form-control mb-3" id="description" name="description"></textarea>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                <button type="submit" class="btn btn-primary">Tambah</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Table -->
        <table id="tb-logistikKeluar" class="table table-bordered table-striped" style="width:100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Tanggal Keluar</th>
                    <th>Logistik</th>
                    <th>Penyuplai</th>
                    <th>Unit Penerima</th>
                    <th>Penerima</th>
                    <th>Jumlah</th>
                    <th>Satuan</th>
                    <th>Keterangan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $outboundLogistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outboundLogistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($outboundLogistic->outboundDate); ?></td>
                        <td><?php echo e($outboundLogistic->inboundLogistic->logistic->name); ?></td>
                        <td><?php echo e($outboundLogistic->inboundLogistic->supplier->name); ?></td>
                        <td><?php echo e($outboundLogistic->receiver->receiverUnit->name); ?></td>
                        <td><?php echo e($outboundLogistic->receiver->name); ?></td>
                        <td><?php echo e($outboundLogistic->quantity); ?></td>
                        <td><?php echo e($outboundLogistic->inboundLogistic->logistic->standardUnit->name); ?></td>
                        <td><?php echo e($outboundLogistic->description); ?></td>
                        <td>
                            <form action="/logistik-keluar/<?php echo e($outboundLogistic->id); ?>" method="post"
                                class="d-inline"
                                onsubmit="return confirm('Apakah Anda yakin untuk menghapus data ini?')">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger btn-sm" type="submit">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ekaprynthara/public_html/test/resources/views//logistik-keluar.blade.php ENDPATH**/ ?>