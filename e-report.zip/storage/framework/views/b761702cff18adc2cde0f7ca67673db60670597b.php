<?php $__env->startSection('body'); ?>
    <div class="h1 fw-bold">Penyuplai</div>
    <div class="container rounded p-3 bg-white mb-3">
        <div class="d-flex justify-content-end align items center mb-2">
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                Tambah
            </button>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title fw-bold" id="exampleModalLabel">Tambah Penyuplai</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="penyuplai" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row mb-3">
                                <div class="col">
                                    <label for="addName" class="form-label">Penyuplai</label>
                                    <input type="text" class="form-control" id="addName" name="name">
                                </div>
                                <div class="col">
                                    <label for="addAddress" class="form-label">Alamat</label>
                                    <input type="text" class="form-control" id="addAddress" name="address">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <label for="addContactPerson" class="form-label">Narahubung</label>
                                    <input type="text" class="form-control" id="addContactPerson" name="contactPerson">
                                </div>
                                <div class="col">
                                    <label for="addTelephone" class="form-label">Telepon</label>
                                    <input type="tel" class="form-control" id="addTelephone" name="telephone">
                                </div>
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- CRUD Alert -->
        <?php if(session()->has('create')): ?>
            <div class="alert alert-success" id="success-alert" role="alert">
                <?php echo e(session('create')); ?>

            </div>
        <?php elseif(session()->has('update')): ?>
            <div class="alert alert-warning" id="warning-alert" role="alert">
                <?php echo e(session('update')); ?>

            </div>
        <?php elseif(session()->has('delete')): ?>
            <div class="alert alert-danger" id="danger-alert" role="alert">
                <?php echo e(session('delete')); ?>

            </div>
        <?php endif; ?>

        <!-- Table -->
        <table id="tb-penyuplai" class="table table-bordered table-striped" style="width:100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Penyuplai</th>
                    <th>Alamat</th>
                    <th>Narahubung</th>
                    <th>Telepon</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($supplier->name); ?></td>
                        <td><?php echo e($supplier->address); ?></td>
                        <td><?php echo e($supplier->contactPerson); ?></td>
                        <td><?php echo e($supplier->telephone); ?></td>
                        <td class="mb-1">
                            <!-- Modal Info -->
                            <a class="btn btn-sm btn-success text-light me-1" data-bs-toggle="modal"
                                data-bs-target="#modalInfo<?php echo e($supplier->id); ?>">Info</a>
                            <div class="modal fade" id="modalInfo<?php echo e($supplier->id); ?>" tabindex="-1"
                                aria-labelledby="detailLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title fw-bold" id="detailLabel">Info</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form>
                                                <div class="row mb-3">
                                                    <div class="col">
                                                        <label for="infoName<?php echo e($supplier->id); ?>"
                                                            class="form-label">Penyuplai</label>
                                                        <input type="text" class="form-control"
                                                            id="infoName<?php echo e($supplier->id); ?>"
                                                            value="<?php echo e($supplier->name); ?>" disabled>
                                                    </div>
                                                    <div class="col">
                                                        <label for="infoAddress<?php echo e($supplier->address); ?>"
                                                            class="form-label">Alamat</label>
                                                        <input type="text" class="form-control"
                                                            id="infoAddress<?php echo e($supplier->address); ?>"
                                                            value="<?php echo e($supplier->address); ?>" disabled>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col">
                                                        <label for="infoContactPerson<?php echo e($supplier->contactPerson); ?>"
                                                            class="form-label">Narahubung</label>
                                                        <input type="text" class="form-control"
                                                            id="infoContactPerson<?php echo e($supplier->contactPerson); ?>"
                                                            value="<?php echo e($supplier->contactPerson); ?>" disabled>
                                                    </div>
                                                    <div class="col">
                                                        <label for="infoTelephone<?php echo e($supplier->id); ?>"
                                                            class="form-label">Telepon</label>
                                                        <input type="tel" class="form-control"
                                                            id="infoTelephone<?php echo e($supplier->id); ?>"
                                                            value="<?php echo e($supplier->telephone); ?>" disabled>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Tutup</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Modal Edit -->
                            <a class="btn btn-sm btn-warning text-light me-1" data-bs-toggle="modal"
                                data-bs-target="#modalEdit<?php echo e($supplier->id); ?>">Edit</a>
                            <div class="modal fade" id="modalEdit<?php echo e($supplier->id); ?>" tabindex="-1"
                                aria-labelledby="detailLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title fw-bold" id="detailLabel">Edit</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="penyuplai/<?php echo e($supplier->id); ?>" method="post">
                                                <?php echo method_field('put'); ?>
                                                <?php echo csrf_field(); ?>
                                                <div class="row mb-3">
                                                    <div class="col">
                                                        <label for="editName<?php echo e($supplier->id); ?>"
                                                            class="form-label">Penyuplai</label>
                                                        <input type="text" class="form-control"
                                                            id="editName<?php echo e($supplier->id); ?>"
                                                            value="<?php echo e($supplier->name); ?>" name="name">
                                                    </div>
                                                    <div class="col">
                                                        <label for="editAddress<?php echo e($supplier->address); ?>"
                                                            class="form-label">Alamat</label>
                                                        <input type="text" class="form-control"
                                                            id="editAddress<?php echo e($supplier->address); ?>"
                                                            value="<?php echo e($supplier->address); ?>" name="address">
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col">
                                                        <label for="editContactPerson<?php echo e($supplier->contactPerson); ?>"
                                                            class="form-label">Narahubung</label>
                                                        <input type="text" class="form-control"
                                                            id="editContactPerson<?php echo e($supplier->contactPerson); ?>"
                                                            value="<?php echo e($supplier->contactPerson); ?>" name="contactPerson">
                                                    </div>
                                                    <div class="col">
                                                        <label for="editTelephone<?php echo e($supplier->id); ?>"
                                                            class="form-label">Telepon</label>
                                                        <input type="tel" class="form-control"
                                                            id="editTelephone<?php echo e($supplier->id); ?>"
                                                            value="<?php echo e($supplier->telephone); ?>" name="telephone">
                                                    </div>
                                                </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Tutup</button>
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- Modal Hapus -->
                            <form action="penyuplai/<?php echo e($supplier->id); ?>" method="post" class="d-inline"
                                onsubmit="return confirm('Apakah Anda yakin untuk menghapus data <?php echo e($supplier->name); ?>?')">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger btn-sm" type="submit">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pyzakke/public_html/test/resources/views/penyuplai.blade.php ENDPATH**/ ?>